package com.litematlist.config;

import java.nio.file.Files;
import java.nio.file.Path;
import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fi.dy.masa.malilib.config.ConfigUtils;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.config.IConfigHandler;
import fi.dy.masa.malilib.config.options.ConfigBoolean;
import fi.dy.masa.malilib.util.FileUtils;
import fi.dy.masa.malilib.util.JsonUtils;
import com.litematlist.LitematListMod;

public class Configs implements IConfigHandler
{
    private static final String CONFIG_FILE_NAME = LitematListMod.MOD_ID + ".json";

    public static class Generic
    {
        public static final ConfigBoolean SHOW_ESC_HINT = new ConfigBoolean(
                "showEscHint",
                true,
                "全屏预览时显示「按ESC退出」悬浮提示"
        ).apply(LitematListMod.MOD_ID + ".config.generic");

        public static final ConfigBoolean ALLOW_MANUAL_REORDER = new ConfigBoolean(
                "allowManualReorder",
                false,
                "允许玩家手动拖拽改变材料顺序"
        ).apply(LitematListMod.MOD_ID + ".config.generic");

        public static final ImmutableList<IConfigBase> OPTIONS = ImmutableList.of(
                SHOW_ESC_HINT,
                ALLOW_MANUAL_REORDER
        );
    }

    public static void loadFromFile()
    {
        Path configFile = FileUtils.getConfigDirectoryAsPath().resolve(CONFIG_FILE_NAME);

        if (Files.exists(configFile) && Files.isReadable(configFile))
        {
            JsonElement element = JsonUtils.parseJsonFileAsPath(configFile);

            if (element != null && element.isJsonObject())
            {
                JsonObject root = element.getAsJsonObject();
                ConfigUtils.readConfigBase(root, "Generic", Generic.OPTIONS);
                ConfigUtils.readConfigBase(root, "Hotkeys", Hotkeys.HOTKEY_LIST);
            }
        }
    }

    public static void saveToFile()
    {
        Path dir = FileUtils.getConfigDirectoryAsPath();

        if (Files.exists(dir) == false)
        {
            try { Files.createDirectories(dir); }
            catch (Exception e) { LitematListMod.LOGGER.error("创建配置目录失败", e); }
        }

        Path configFile = dir.resolve(CONFIG_FILE_NAME);
        JsonObject root = new JsonObject();

        ConfigUtils.writeConfigBase(root, "Generic", Generic.OPTIONS);
        ConfigUtils.writeConfigBase(root, "Hotkeys", Hotkeys.HOTKEY_LIST);

        JsonUtils.writeJsonToFileAsPath(root, configFile);
    }

    @Override
    public void load()
    {
        loadFromFile();
    }

    @Override
    public void save()
    {
        saveToFile();
    }
}