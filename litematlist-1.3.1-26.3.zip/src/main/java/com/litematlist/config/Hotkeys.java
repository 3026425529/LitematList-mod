package com.litematlist.config;

import java.util.List;
import com.google.common.collect.ImmutableList;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.hotkeys.KeybindSettings;
import com.litematlist.LitematListMod;

public class Hotkeys
{
    private static final String HOTKEYS_KEY = LitematListMod.MOD_ID + ".config.hotkeys";

    public static final ConfigHotkey OPEN_MAIN_GUI = new ConfigHotkey(
            "openMainGui",
            "L,C",
            KeybindSettings.RELEASE_EXCLUSIVE,
            "litematlist.config.hotkeys.comment.openMainGui",
            "打开 LitematList 材料列表",
            "litematlist.config.hotkeys.name.openMainGui"
    ).apply(HOTKEYS_KEY);

    public static final List<ConfigHotkey> HOTKEY_LIST = ImmutableList.of(
            OPEN_MAIN_GUI
    );
}