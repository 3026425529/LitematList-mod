package com.litematlist.gui;

import com.litematlist.LitematicReader;
import com.litematlist.MaterialListImporter;
import com.litematlist.I18n;
import com.litematlist.LitematListMod;
import com.litematlist.config.Configs;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.BlitRenderState;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import fi.dy.masa.malilib.render.GuiContext;
import org.apache.commons.lang3.tuple.Pair;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.GpuSampler;
import org.joml.Matrix3x2f;

import java.io.*;
import java.nio.file.Path;
import java.util.*;

/**
 * 材料清单子界面 —— 参照投影的 MaterialList 界面布局。
 * 总计/已有/缺失左置，替换/忽略按钮贴右。
 */
public class MaterialDetailScreen extends GuiBase {

    private final GuiBase parent;
    private final String schematicName;
    private final Path filePath;
    private final List<MaterialRow> rows = new ArrayList<>();
    private int scrollOffset = 0;
    private static final int ROW_HEIGHT = 22;
    private static final int HEADER_Y = 42;
    private static final int HEADER_HEIGHT = 16;
    private static final int LIST_TOP = HEADER_Y + HEADER_HEIGHT + 2;
    private static final int PIN_ICON_SIZE = 16;
    private static final int PIN_ICON_Y_OFFSET = 2;
    private int visibleRows;

    // ---- 置顶图标纹理 ----
    private static final Identifier PIN_EMPTY = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/empty.png");
    private static final Identifier PIN_FAVORITE = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/favorite.png");
    private static final Identifier PIN_HOVERED_EMPTY = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/hovered_empty.png");
    private static final Identifier PIN_HOVERED_FAVORITE = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/hovered_favorite.png");
    private static final Identifier PIN_FOCUSED = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/focused_outline.png");
    private boolean loaded = false;
    private int hoveredRow = -1;
    private int hoveredColumn = -1; // 0=总计, 1=已有, 2=缺失

    // ---- 已忽略物品 ----
    private static final Map<Path, Set<Item>> ignoredItems = new HashMap<>();
    private Set<Item> currentIgnored;

    // ---- 替换映射（持久化：原理图路径 → 原始物品ID → 替换物品ID） ----
    private static final Map<String, Map<String, String>> replacements = new HashMap<>();
    private static boolean persistenceLoaded = false;
    private static final Gson GSON = new Gson();
    private static Path persistenceFile;

    // ---- 导入材料缓存（txt 文件导入的材料列表，不经过 .litematic 解析） ----
    private static final Map<Path, List<LitematicReader.MaterialEntry>> importedMaterials = new HashMap<>();

    /**
     * 缓存从 txt 导入的材料列表，供 MaterialDetailScreen 加载时使用。
     */
    public static void cacheMaterialList(Path filePath, List<LitematicReader.MaterialEntry> materials) {
        importedMaterials.put(filePath, materials);
    }

    private static void ensurePersistenceLoaded() {
        if (persistenceLoaded) return;
        persistenceLoaded = true;
        persistenceFile = FabricLoader.getInstance().getConfigDir().resolve("litematlist/persistence.json");

        if (java.nio.file.Files.exists(persistenceFile)) {
            try (Reader reader = new InputStreamReader(new FileInputStream(persistenceFile.toFile()), java.nio.charset.StandardCharsets.UTF_8)) {
                JsonObject root = GSON.fromJson(reader, JsonObject.class);
                if (root != null) {
                    // 加载 ignored
                    JsonObject ignoredData = root.getAsJsonObject("ignored");
                    if (ignoredData != null) {
                        for (var entry : ignoredData.entrySet()) {
                            Path path = Path.of(entry.getKey());
                            Set<Item> items = new HashSet<>();
                            JsonObject itemsObj = entry.getValue().getAsJsonObject();
                            for (String itemId : itemsObj.keySet()) {
                                var holder = BuiltInRegistries.ITEM.get(Identifier.parse(itemId));
                                if (holder.isPresent()) {
                                    Item item = holder.get().value();
                                    if (item != null) items.add(item);
                                }
                            }
                            ignoredItems.put(path, items);
                        }
                    }
                    // 加载 replacements
                    JsonObject replData = root.getAsJsonObject("replacements");
                    if (replData != null) {
                        for (var entry : replData.entrySet()) {
                            Map<String, String> map = new HashMap<>();
                            JsonObject inner = entry.getValue().getAsJsonObject();
                            for (var e : inner.entrySet()) {
                                map.put(e.getKey(), e.getValue().getAsString());
                            }
                            replacements.put(entry.getKey(), map);
                        }
                    }
                    // 加载 entries
                    JsonArray entriesArr = root.getAsJsonArray("entries");
                    if (entriesArr != null) {
                        for (JsonElement elem : entriesArr) {
                            JsonObject obj = elem.getAsJsonObject();
                            String name = obj.get("name").getAsString();
                            Path path = Path.of(obj.get("path").getAsString());
                            boolean pinned = obj.has("pinned") && obj.get("pinned").getAsBoolean();
                            boolean fromLitematica = obj.has("fromLitematica") && obj.get("fromLitematica").getAsBoolean();
                            MaterialListScreen.addEntryInternal(name, path, fromLitematica, pinned);
                        }
                        LitematListMod.LOGGER.info("已加载 {} 个持久化条目", entriesArr.size());
                    }
                    // 加载 pinnedItems（材料清单中的置顶物品）
                    JsonObject pinnedData = root.getAsJsonObject("pinnedItems");
                    if (pinnedData != null) {
                        for (var entry : pinnedData.entrySet()) {
                            Path path = Path.of(entry.getKey());
                            Set<Item> items = new HashSet<>();
                            JsonArray arr = entry.getValue().getAsJsonArray();
                            for (JsonElement e : arr) {
                                var holder = BuiltInRegistries.ITEM.get(Identifier.parse(e.getAsString()));
                                if (holder.isPresent()) {
                                    Item item = holder.get().value();
                                    if (item != null) items.add(item);
                                }
                            }
                            pinnedItems.put(path, items);
                        }
                    }
                }
                LitematListMod.LOGGER.info("已加载持久化数据: {} 个忽略集, {} 个替换映射", ignoredItems.size(), replacements.size());
            } catch (Exception e) {
                LitematListMod.LOGGER.error("加载持久化数据失败", e);
            }
        }
    }

    /** 保存所有持久化数据（忽略、替换、条目列表） */
    public static void savePersistence() {
        if (persistenceFile == null) return;
        try {
            JsonObject root = new JsonObject();

            // ignored
            JsonObject ignoredData = new JsonObject();
            for (var entry : ignoredItems.entrySet()) {
                JsonObject items = new JsonObject();
                for (Item item : entry.getValue()) {
                    Identifier id = BuiltInRegistries.ITEM.getKey(item);
                    if (id != null) items.addProperty(id.toString(), "");
                }
                ignoredData.add(entry.getKey().toString(), items);
            }
            root.add("ignored", ignoredData);

            // replacements
            JsonObject replData = new JsonObject();
            for (var entry : replacements.entrySet()) {
                JsonObject inner = new JsonObject();
                for (var e : entry.getValue().entrySet()) {
                    inner.addProperty(e.getKey(), e.getValue());
                }
                replData.add(entry.getKey(), inner);
            }
            root.add("replacements", replData);

            // entries
            JsonArray entriesArr = new JsonArray();
            for (MaterialListScreen.LoadedEntry le : MaterialListScreen.getLoadedEntries()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("name", le.name());
                obj.addProperty("path", le.filePath().toString());
                obj.addProperty("pinned", le.pinned);
                obj.addProperty("fromLitematica", le.fromLitematica());
                entriesArr.add(obj);
            }
            root.add("entries", entriesArr);

            // pinnedItems（材料清单中的置顶物品）
            JsonObject pinnedData = new JsonObject();
            for (var entry : pinnedItems.entrySet()) {
                JsonArray arr = new JsonArray();
                for (Item item : entry.getValue()) {
                    Identifier id = BuiltInRegistries.ITEM.getKey(item);
                    if (id != null) arr.add(id.toString());
                }
                if (!arr.isEmpty()) {
                    pinnedData.add(entry.getKey().toString(), arr);
                }
            }
            root.add("pinnedItems", pinnedData);

            // 确保目录存在
            java.nio.file.Files.createDirectories(persistenceFile.getParent());
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(persistenceFile.toFile()), java.nio.charset.StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
            LitematListMod.LOGGER.info("已保存持久化数据 ({} 个条目)", entriesArr.size());
        } catch (Exception e) {
            LitematListMod.LOGGER.error("保存持久化数据失败", e);
        }
    }

    /** 获取替换物品（如果有），否则返回原物品 */
    private static Item getReplacement(Path filePath, Item original) {
        ensurePersistenceLoaded();
        String pathKey = filePath.toString();
        Map<String, String> fileReplacements = replacements.get(pathKey);
        if (fileReplacements == null) return original;
        Identifier origId = BuiltInRegistries.ITEM.getKey(original);
        if (origId == null) return original;
        String replId = fileReplacements.get(origId.toString());
        if (replId == null) return original;
        var holder = BuiltInRegistries.ITEM.get(Identifier.parse(replId));
        return holder.isPresent() ? holder.get().value() : original;
    }

    /** 供外部调用，初始化持久化 */
    public static void initPersistence() {
        ensurePersistenceLoaded();
    }

    /** 清理指定路径的持久化数据（替换映射和忽略物品） */
    public static void cleanupPathData(Path filePath) {
        ensurePersistenceLoaded();
        String pathKey = filePath.toString();
        replacements.remove(pathKey);
        ignoredItems.remove(filePath);
        pinnedItems.remove(filePath);
        importedMaterials.remove(filePath);
        LitematListMod.LOGGER.info("已清理路径持久化数据: {}", pathKey);
    }

    /** 判断物品是否已被替换 */
    private static boolean isReplaced(Path filePath, Item original) {
        return getReplacement(filePath, original) != original;
    }

    // ---- 替换模式 ----
    private int replacingRow = -1; // 当前处于替换模式的行索引

    // ---- 隐藏不缺材料 ----
    private boolean hideNoMissing = false;
    // 隐藏不缺材料按钮位置（用于自定义渲染开/关颜色）
    private int hideBtnX, hideBtnY, hideBtnW;
    private String hideBtnLabel = "";
    // ---- 手动重排 ----
    private static final Map<Path, List<Item>> reorderedItems = new HashMap<>();
    private int draggedRow = -1;
    private int dragStartY = 0;
    private boolean isDragging = false;

    // ---- 列位置 ----
    private int colTotalX;
    private int colHaveX;
    private int colMissX;

    // ---- 排序 ----
    private SortMode sortMode = SortMode.NONE;

    private enum SortMode {
        NONE(""),
        TOTAL_DESC("▼"),
        TOTAL_ASC("▲"),
        HAVE_DESC("▼"),
        HAVE_ASC("▲"),
        MISS_DESC("▼"),
        MISS_ASC("▲");

        final String arrow;
        SortMode(String arrow) { this.arrow = arrow; }
    }

    // ---- 按钮布局 ----
    private static final int BTN_REPLACE_W = 52;
    private static final int BTN_IGNORE_W = 52;
    private static final int BTN_CANCEL_W = 52;
    private static final int BTN_GAP = 2;
    private static final int BTN_RIGHT_MARGIN = 12;

    // ---- 标记材料 ----
    private boolean allowPin = true;
    private int pinBtnX, pinBtnY, pinBtnW;
    private String pinBtnLabel = "";
    private static final Map<Path, Set<Item>> pinnedItems = new HashMap<>();
    private Set<Item> currentPinned;

    // 按钮区域左边界
    private int buttonAreaStart;

    public MaterialDetailScreen(GuiBase parent, String schematicName, Path filePath) {
        super();
        this.parent = parent;
        this.schematicName = schematicName;
        this.filePath = filePath;
        this.title = I18n.tr("litematlist.title.material_detail", schematicName);
        this.currentIgnored = ignoredItems.computeIfAbsent(filePath, k -> new HashSet<>());
        this.currentPinned = pinnedItems.computeIfAbsent(filePath, k -> new HashSet<>());
    }

    @Override
    public void initGui() {
        super.initGui();
        this.replacingRow = -1; // 每次重建界面时清除选择模式
        this.visibleRows = (this.height - 100) / ROW_HEIGHT;

        if (!loaded) {
            loadMaterials();
            loaded = true;
        }
        calculateColumnPositions();

        this.buttonAreaStart = this.width - BTN_RIGHT_MARGIN - BTN_IGNORE_W - BTN_GAP - BTN_REPLACE_W - BTN_GAP - BTN_CANCEL_W - BTN_GAP;

        int buttonY = this.height - 38;

        ButtonGeneric backButton = new ButtonGeneric(this.width / 2 - 60, buttonY, 120, 20, I18n.tr("litematlist.button.back"));
        backButton.setRenderDefaultBackground(true);
        this.addButton(backButton, (IButtonActionListener) (btn, mb) ->
                Minecraft.getInstance().setScreen(parent));

        int ignoredCount = currentIgnored.size();
        String ignoredLabel = ignoredCount > 0 ? I18n.tr("litematlist.button.ignored_count", ignoredCount) : I18n.tr("litematlist.button.ignored");
        int ignoredBtnW = Math.max(60, this.font.width(ignoredLabel) + 16);

        // 隐藏不缺材料按钮 —— 放在"物品"表头上方
        String hideLabel = hideNoMissing ? I18n.tr("litematlist.button.hide_no_missing_on") : I18n.tr("litematlist.button.hide_no_missing_off");
        int hideBtnW = Math.max(60, this.font.width(hideLabel) + 16);
        int hideBtnX = 20;
        int hideBtnY = 20;
        ButtonGeneric hideBtn = new ButtonGeneric(hideBtnX, hideBtnY, hideBtnW, 20, "");
        hideBtn.setRenderDefaultBackground(true);
        this.addButton(hideBtn, (IButtonActionListener) (b, mb) -> {
            hideNoMissing = !hideNoMissing;
            initGui();
        });
        // 保存按钮位置用于自定义渲染
        this.hideBtnX = hideBtnX;
        this.hideBtnY = hideBtnY;
        this.hideBtnW = hideBtnW;
        this.hideBtnLabel = hideLabel;

        // 允许标记材料按钮
        String pinLabel = allowPin ? I18n.tr("litematlist.button.allow_pin_on") : I18n.tr("litematlist.button.allow_pin_off");
        int pinBtnW = Math.max(60, this.font.width(pinLabel) + 16);
        int pinBtnX = hideBtnX + hideBtnW + 4;
        int pinBtnY = 20;
        ButtonGeneric pinBtn = new ButtonGeneric(pinBtnX, pinBtnY, pinBtnW, 20, "");
        pinBtn.setRenderDefaultBackground(true);
        this.addButton(pinBtn, (IButtonActionListener) (b, mb) -> {
            allowPin = !allowPin;
            initGui();
        });
        this.pinBtnX = pinBtnX;
        this.pinBtnY = pinBtnY;
        this.pinBtnW = pinBtnW;
        this.pinBtnLabel = pinLabel;

        ButtonGeneric ignoredBtn = new ButtonGeneric(
                this.width - ignoredBtnW - 12, 10, ignoredBtnW, 20, ignoredLabel);
        ignoredBtn.setRenderDefaultBackground(true);
        this.addButton(ignoredBtn, (IButtonActionListener) (b, mb) -> {
            Map<Item, Integer> ignoredTotals = new HashMap<>();
            for (MaterialRow row : rows) {
                if (currentIgnored.contains(row.item)) {
                    ignoredTotals.put(row.item, row.totalCount);
                }
            }
            Minecraft.getInstance().setScreen(
                    new IgnoredItemsScreen(this, schematicName, filePath, currentIgnored, ignoredTotals));
        });

        createRowButtons();
    }

    private void calculateColumnPositions() {
        int maxTotalWidth = this.font.width(I18n.tr("litematlist.header.total"));
        int maxHaveWidth = this.font.width(I18n.tr("litematlist.header.have"));
        int maxMissWidth = this.font.width(I18n.tr("litematlist.header.missing"));
        int maxNameWidth = this.font.width(I18n.tr("litematlist.header.item"));

        for (MaterialRow row : rows) {
            maxNameWidth = Math.max(maxNameWidth, this.font.width(row.name));
            maxTotalWidth = Math.max(maxTotalWidth, this.font.width(String.valueOf(row.totalCount)));
        }

        int nameEndX = 35 + maxNameWidth + 20;
        colTotalX = nameEndX + 24;
        colHaveX = colTotalX + maxTotalWidth + 24;
        colMissX = colHaveX + maxHaveWidth + 24;
    }

    private void loadMaterials() {
        rows.clear();
        ensurePersistenceLoaded();
        try {
            // 优先从导入缓存加载（txt 文件导入的材料）
            List<LitematicReader.MaterialEntry> entries;
            if (importedMaterials.containsKey(filePath)) {
                entries = importedMaterials.get(filePath);
                LitematListMod.LOGGER.info("从导入缓存加载材料: {} ({} 种)", filePath, entries.size());
            } else if (filePath.toString().toLowerCase().endsWith(".txt") || filePath.toString().toLowerCase().endsWith(".json")) {
                // txt/json 文件：重启后缓存已丢失，重新解析
                LitematListMod.LOGGER.info("文件重新解析: {}", filePath);
                MaterialListImporter.ImportResult result = MaterialListImporter.importFromFile(filePath);
                if (result != null) {
                    entries = result.materials();
                    importedMaterials.put(filePath, entries); // 重新缓存
                } else {
                    LitematListMod.LOGGER.error("txt 文件重新解析失败: {}", filePath);
                    return;
                }
            } else {
                entries = LitematicReader.loadMaterialList(filePath);
            }
            // 获取缺失数量（仅 txt 文件有）
            Map<Item, Integer> missingMap = MaterialListImporter.getMissingCounts(filePath);
            for (LitematicReader.MaterialEntry entry : entries) {
                Item item = entry.item();
                // 应用已保存的替换
                Item replaced = getReplacement(filePath, item);
                int missing = missingMap.getOrDefault(item, 0);
                rows.add(new MaterialRow(
                        new ItemStack(replaced, entry.totalCount()),
                        replaced.getName(new ItemStack(replaced)).getString(),
                        entry.totalCount(),
                        replaced,
                        item, // originalItem 始终是原理图原始物品
                        missing
                ));
            }
            LitematListMod.LOGGER.info("加载了 {} 种材料（已忽略 {} 种）", rows.size(), currentIgnored.size());
        } catch (Exception e) {
            LitematListMod.LOGGER.error("解析材料列表失败: {}", filePath, e);
        }
    }

    private void createRowButtons() {
        List<MaterialRow> displayRows = getSortedRows();
        int maxIdx = Math.min(displayRows.size(), scrollOffset + visibleRows);

        for (int i = scrollOffset; i < maxIdx; i++) {
            MaterialRow row = displayRows.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;
            final int visibleIdx = i;

            int ignoreX = this.width - BTN_RIGHT_MARGIN - BTN_IGNORE_W;
            int replaceX = ignoreX - BTN_GAP - BTN_REPLACE_W;
            int cancelX = replaceX - BTN_GAP - BTN_CANCEL_W;

            final MaterialRow targetRow = row;

            // 取消替换按钮（物品已被替换时显示，可恢复为原理图原始物品）
            if (row.item != row.originalItem) {
                ButtonGeneric cancelBtn = new ButtonGeneric(cancelX, rowY + 1, BTN_CANCEL_W, 20, I18n.tr("litematlist.button.cancel_replace"));
                cancelBtn.setRenderDefaultBackground(true);
                this.addButton(cancelBtn, (IButtonActionListener) (b, mb) -> {
                    restoreOriginalItem(targetRow);
                    initGui();
                });
            }

            // 替换按钮
            ButtonGeneric replaceBtn = new ButtonGeneric(replaceX, rowY + 1, BTN_REPLACE_W, 20, I18n.tr("litematlist.button.replace"));
            replaceBtn.setRenderDefaultBackground(true);
            this.addButton(replaceBtn, (IButtonActionListener) (b, mb) -> {
                replacingRow = visibleIdx;
                Minecraft.getInstance().setScreen(
                        new BlockPickerScreen(this, newItem -> replaceItem(targetRow, newItem)));
            });

            // 忽略按钮（置顶材料不显示忽略按钮）
            if (!(allowPin && currentPinned.contains(row.originalItem))) {
                ButtonGeneric ignoreBtn = new ButtonGeneric(ignoreX, rowY + 1, BTN_IGNORE_W, 20, I18n.tr("litematlist.button.ignore"));
                ignoreBtn.setRenderDefaultBackground(true);
                this.addButton(ignoreBtn, (IButtonActionListener) (b, mb) -> {
                    ignoreItem(visibleIdx);
                    initGui();
                });
            }
        }
    }

    private void ignoreItem(int visibleIdx) {
        replacingRow = -1; // 点击忽略时取消替换模式
        List<MaterialRow> displayRows = getSortedRows();
        if (visibleIdx >= 0 && visibleIdx < displayRows.size()) {
            MaterialRow row = displayRows.get(visibleIdx);
            if (allowPin && currentPinned.contains(row.originalItem)) return;
            currentIgnored.add(row.item);
            savePersistence(); // 立即持久化忽略
            LitematListMod.LOGGER.info("忽略物品: {} ({})", row.name, row.item);
        }
    }

    private List<MaterialRow> getVisibleRowsOnly() {
        List<MaterialRow> visible = new ArrayList<>();
        for (MaterialRow row : rows) {
            if (!currentIgnored.contains(row.item)) {
                if (hideNoMissing) {
                    int haveCount = getPlayerItemCount(row.item);
                    if (row.totalCount - haveCount <= 0) continue;
                }
                visible.add(row);
            }
        }
        // 应用手动重排顺序
        List<Item> reorder = reorderedItems.get(filePath);
        if (reorder != null && !reorder.isEmpty()) {
            Map<Item, MaterialRow> rowMap = new HashMap<>();
            for (MaterialRow row : visible) {
                rowMap.put(row.originalItem, row);
            }
            List<MaterialRow> ordered = new ArrayList<>();
            for (Item item : reorder) {
                MaterialRow row = rowMap.get(item);
                if (row != null) {
                    ordered.add(row);
                    rowMap.remove(item);
                }
            }
            ordered.addAll(rowMap.values());
            visible = ordered;
        }
        // 标记材料模式：将已标记的材料排到最前面
        if (allowPin && !currentPinned.isEmpty()) {
            List<MaterialRow> pinned = new ArrayList<>();
            List<MaterialRow> unpinned = new ArrayList<>();
            for (MaterialRow row : visible) {
                if (currentPinned.contains(row.originalItem)) {
                    pinned.add(row);
                } else {
                    unpinned.add(row);
                }
            }
            pinned.addAll(unpinned);
            visible = pinned;
        }
        return visible;
    }

    private int getPlayerItemCount(Item item) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return 0;
        int count = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = client.player.getInventory().getItem(i);
            if (stack.getItem() == item) {
                count += stack.getCount();
            }
        }
        return count;
    }

    private String[] formatCountTooltip(int count) {
        int shulker = count / 1728;
        int remainder = count % 1728;
        int stacks = remainder / 64;
        int items = remainder % 64;
        double shulkerFloat = (double) count / 1728.0;
        return new String[] {
            String.format("%d = %d×1728 + %d×64 + %d  |", count, shulker, stacks, items),
            String.format(" = %d×64+%d  |", shulker * 27 + stacks, items),
            String.format(" ≈%.2f 潜影盒  |", shulkerFloat)
        };
    }

    private void drawCountTooltip(GuiContext ctx, String[] lines, int mouseX, int mouseY) {
        int maxW = 0;
        for (String line : lines) {
            maxW = Math.max(maxW, this.font.width(line));
        }
        int lineH = 12;
        int padX = 6;
        int padY = 4;
        int tipW = maxW + padX * 2;
        int tipH = lines.length * lineH + padY * 2;
        int tipX = mouseX + 12;
        int tipY = mouseY - tipH;
        if (tipX + tipW > this.width) tipX = this.width - tipW - 4;
        if (tipY < 4) tipY = mouseY + 16;

        ctx.fill(tipX, tipY, tipX + tipW, tipY + tipH, 0xCC000000);
        ctx.fill(tipX + 1, tipY + 1, tipX + tipW - 1, tipY + tipH - 1, 0xCC333333);
        for (int i = 0; i < lines.length; i++) {
            ctx.drawString(this.font, lines[i], tipX + padX, tipY + padY + i * lineH, 0xFFFFFFFF);
        }
    }

    private List<MaterialRow> getSortedRows() {
        List<MaterialRow> visible = getVisibleRowsOnly();

        // 分离置顶和非置顶
        if (allowPin && !currentPinned.isEmpty()) {
            List<MaterialRow> pinned = new ArrayList<>();
            List<MaterialRow> unpinned = new ArrayList<>();
            for (MaterialRow row : visible) {
                if (currentPinned.contains(row.originalItem)) {
                    pinned.add(row);
                } else {
                    unpinned.add(row);
                }
            }
            // 只对非置顶项排序
            if (sortMode != SortMode.NONE) {
                unpinned = sortRowList(unpinned);
            }
            pinned.addAll(unpinned);
            return pinned;
        }

        if (sortMode == SortMode.NONE) return visible;
        return sortRowList(visible);
    }

    private List<MaterialRow> sortRowList(List<MaterialRow> list) {
        List<SortableRow> sortable = new ArrayList<>();
        for (MaterialRow row : list) {
            int haveCount = getPlayerItemCount(row.item);
            sortable.add(new SortableRow(row, haveCount, Math.max(0, row.totalCount - haveCount)));
        }

        Comparator<SortableRow> cmp = switch (sortMode) {
            case TOTAL_DESC -> Comparator.comparingInt((SortableRow r) -> r.row.totalCount).reversed();
            case TOTAL_ASC -> Comparator.comparingInt(r -> r.row.totalCount);
            case HAVE_DESC -> Comparator.comparingInt((SortableRow r) -> r.haveCount).reversed();
            case HAVE_ASC -> Comparator.comparingInt(r -> r.haveCount);
            case MISS_DESC -> Comparator.comparingInt((SortableRow r) -> r.missCount).reversed();
            case MISS_ASC -> Comparator.comparingInt(r -> r.missCount);
            default -> null;
        };

        if (cmp == null) return list;
        sortable.sort(cmp);
        return sortable.stream().map(r -> r.row).toList();
    }

    private record SortableRow(MaterialRow row, int haveCount, int missCount) {}

    private void handleHeaderClick(double mouseX, double mouseY) {
        if (mouseY < HEADER_Y || mouseY > HEADER_Y + HEADER_HEIGHT) return;

        if (mouseX >= colTotalX - 20 && mouseX <= colTotalX + 30) {
            sortMode = (sortMode == SortMode.TOTAL_DESC) ? SortMode.TOTAL_ASC
                     : (sortMode == SortMode.TOTAL_ASC) ? SortMode.NONE
                     : SortMode.TOTAL_DESC;
            initGui();
        } else if (mouseX >= colHaveX - 20 && mouseX <= colHaveX + 30) {
            sortMode = (sortMode == SortMode.HAVE_DESC) ? SortMode.HAVE_ASC
                     : (sortMode == SortMode.HAVE_ASC) ? SortMode.NONE
                     : SortMode.HAVE_DESC;
            initGui();
        } else if (mouseX >= colMissX - 20 && mouseX <= colMissX + 30) {
            sortMode = (sortMode == SortMode.MISS_DESC) ? SortMode.MISS_ASC
                     : (sortMode == SortMode.MISS_ASC) ? SortMode.NONE
                     : SortMode.MISS_DESC;
            initGui();
        }
    }

    // ==================== 替换逻辑 ====================

    private void replaceItem(MaterialRow target, Item newItem) {
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i).item == target.item) {
                MaterialRow old = rows.get(i);
                rows.set(i, new MaterialRow(
                        new ItemStack(newItem, old.totalCount),
                        newItem.getName(new ItemStack(newItem)).getString(),
                        old.totalCount,
                        newItem,
                        old.originalItem, // 保留原始物品
                        old.missingCount
                ));
                break;
            }
        }
        // 立即持久化替换
        String pathKey = filePath.toString();
        Map<String, String> fileReplacements = replacements.computeIfAbsent(pathKey, k -> new HashMap<>());
        Identifier origId = BuiltInRegistries.ITEM.getKey(target.originalItem);
        Identifier newId = BuiltInRegistries.ITEM.getKey(newItem);
        if (origId != null && newId != null) {
            fileReplacements.put(origId.toString(), newId.toString());
        }
        savePersistence();
        initGui();
    }

    private void restoreOriginalItem(MaterialRow target) {
        for (int i = 0; i < rows.size(); i++) {
            // 通过 originalItem 匹配：替换后 target.item 是旧物品，rows[i].item 是新物品，不能直接 == 比较
            if (rows.get(i).originalItem == target.originalItem) {
                MaterialRow old = rows.get(i);
                Item orig = old.originalItem;
                rows.set(i, new MaterialRow(
                        new ItemStack(orig, old.totalCount),
                        orig.getName(new ItemStack(orig)).getString(),
                        old.totalCount,
                        orig,
                        orig,
                        old.missingCount
                ));
                break;
            }
        }
        // 从持久化中移除替换
        String pathKey = filePath.toString();
        Map<String, String> fileReplacements = replacements.get(pathKey);
        if (fileReplacements != null) {
            Identifier origId = BuiltInRegistries.ITEM.getKey(target.originalItem);
            if (origId != null) {
                fileReplacements.remove(origId.toString());
                if (fileReplacements.isEmpty()) {
                    replacements.remove(pathKey);
                }
            }
        }
        savePersistence();
        replacingRow = -1;
    }

    // ==================== 渲染 ====================

    @Override
    public void extractRenderState(GuiGraphicsExtractor gfx, int mouseX, int mouseY, float partialTicks) {
        GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
        this.extractBackground(gfx, mouseX, mouseY, partialTicks);

        ctx.drawCenteredString(
                this.font, this.title, this.width / 2, 12, 0xFFFFFFFF);

        if (rows.isEmpty()) {
            ctx.drawCenteredString(
                    this.font, I18n.tr("litematlist.error.no_data"),
                    this.width / 2, this.height / 2 - 10, 0xFFFFFFFF);
            super.extractRenderState(gfx, mouseX, mouseY, partialTicks);
            return;
        }

        List<MaterialRow> displayRows = getSortedRows();

        int listRight = this.width - 8; // 背景框覆盖按钮区域
        int listBottom = LIST_TOP + visibleRows * ROW_HEIGHT;

        // ===== 第1层：背景（在按钮之前绘制，避免盖住按钮） =====
        ctx.fill(8, LIST_TOP - 2, listRight, listBottom + 2, 0x40000000);

        hoveredRow = -1;
        hoveredColumn = -1;
        int maxIdx = Math.min(displayRows.size(), scrollOffset + visibleRows);

        for (int i = scrollOffset; i < maxIdx; i++) {
            MaterialRow row = displayRows.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;
            boolean isReplacing = (replacingRow == i);

            if (isReplacing) {
                ctx.fill(10, rowY, listRight, rowY + ROW_HEIGHT, 0x60FFFF00);
            } else if (mouseX >= 10 && mouseX <= listRight
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                hoveredRow = i;
                ctx.fill(10, rowY, listRight, rowY + ROW_HEIGHT, 0x40FFFFFF);

                int totalW = this.font.width(String.valueOf(row.totalCount));
                int haveW = this.font.width(String.valueOf(getPlayerItemCount(row.item)));
                int missW = this.font.width(String.valueOf(Math.max(0, row.totalCount - getPlayerItemCount(row.item))));

                if (mouseX >= colTotalX - 10 && mouseX <= colTotalX + totalW + 10) {
                    hoveredColumn = 0;
                } else if (mouseX >= colHaveX - 10 && mouseX <= colHaveX + haveW + 10) {
                    hoveredColumn = 1;
                } else if (mouseX >= colMissX - 10 && mouseX <= colMissX + missW + 10) {
                    hoveredColumn = 2;
                }
            } else if ((i - scrollOffset) % 2 == 0) {
                ctx.fill(10, rowY, listRight, rowY + ROW_HEIGHT, 0x10FFFFFF);
            }
        }

        // 表头背景
        ctx.fill(8, HEADER_Y, listRight, HEADER_Y + HEADER_HEIGHT, 0x60000000);

        int sortColX = switch (sortMode) {
            case TOTAL_DESC, TOTAL_ASC -> colTotalX;
            case HAVE_DESC, HAVE_ASC -> colHaveX;
            case MISS_DESC, MISS_ASC -> colMissX;
            default -> -1;
        };
        if (sortColX > 0) {
            ctx.fill(sortColX - 20, HEADER_Y, sortColX + 30, HEADER_Y + HEADER_HEIGHT, 0x40FFFF88);
        }

        // ===== 第2层：按钮（在背景之上） =====
        super.extractRenderState(gfx, mouseX, mouseY, partialTicks);

        // 自定义渲染隐藏按钮文字（开=绿色，关=红色）
        if (!hideBtnLabel.isEmpty()) {
            int colonIdx = hideBtnLabel.indexOf("：");
            if (colonIdx < 0) colonIdx = hideBtnLabel.indexOf(":");
            if (colonIdx > 0) {
                String prefix = hideBtnLabel.substring(0, colonIdx + 1);
                String status = hideBtnLabel.substring(colonIdx + 1);
                int prefixW = this.font.width(prefix);
                int textX = hideBtnX + 4;
                int textY = hideBtnY + 5;
                ctx.drawString(this.font, prefix, textX, textY, 0xFFFFFFFF);
                int statusColor = hideNoMissing ? 0xFF55FF55 : 0xFFFF5555;
                ctx.drawString(this.font, status, textX + prefixW, textY, statusColor);
            }
        }
        // 自定义渲染标记按钮文字（开=绿色，关=红色）
        if (!pinBtnLabel.isEmpty()) {
            int colonIdx = pinBtnLabel.indexOf("：");
            if (colonIdx < 0) colonIdx = pinBtnLabel.indexOf(":");
            if (colonIdx > 0) {
                String prefix = pinBtnLabel.substring(0, colonIdx + 1);
                String status = pinBtnLabel.substring(colonIdx + 1);
                int prefixW = this.font.width(prefix);
                int textX = pinBtnX + 4;
                int textY = pinBtnY + 5;
                ctx.drawString(this.font, prefix, textX, textY, 0xFFFFFFFF);
                int statusColor = allowPin ? 0xFF55FF55 : 0xFFFF5555;
                ctx.drawString(this.font, status, textX + prefixW, textY, statusColor);
            }
        }

        // ===== 第3层：文字和物品图标（在最上层） =====
        for (int i = scrollOffset; i < maxIdx; i++) {
            MaterialRow row = displayRows.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;

            int iconX = 15;
            int nameX = 35;

            // 标记材料模式：使用图标纹理
            if (allowPin) {
                int pinX = 15;
                int pinY = rowY + PIN_ICON_Y_OFFSET;
                boolean isPinned = currentPinned.contains(row.originalItem);
                boolean pinHovered = mouseX >= pinX && mouseX <= pinX + PIN_ICON_SIZE
                        && mouseY >= pinY && mouseY <= pinY + PIN_ICON_SIZE;

                Identifier pinTexture;
                if (isPinned) {
                    pinTexture = pinHovered ? PIN_HOVERED_FAVORITE : PIN_FAVORITE;
                } else {
                    pinTexture = pinHovered ? PIN_HOVERED_EMPTY : PIN_EMPTY;
                }
                drawPinIcon(ctx, pinTexture, pinX, pinY);

                if (pinHovered) {
                    drawPinIcon(ctx, PIN_FOCUSED, pinX, pinY);
                }
                iconX = 33;
                nameX = 53;
            }

            ctx.renderItem(row.itemStack, iconX, rowY + 2);
            ctx.drawString(this.font, row.name, nameX, rowY + 5, 0xFFFFFFFF);
            ctx.drawString(this.font, String.valueOf(row.totalCount), colTotalX, rowY + 5, 0xFFFFFFFF);

            int haveCount = getPlayerItemCount(row.item);
            ctx.drawString(this.font, String.valueOf(haveCount), colHaveX, rowY + 5, 0xFFFFFFFF);

            int missCount = Math.max(0, row.totalCount - haveCount);
            int missColor = missCount == 0 ? 0xFF55FF55
                          : (haveCount >= missCount ? 0xFFFFAA00 : 0xFFFF5555);
            ctx.drawString(this.font, String.valueOf(missCount), colMissX, rowY + 5, missColor);
        }

        // 表头文字
        int headerNameX = allowPin ? 53 : 35;
        ctx.drawString(this.font, I18n.tr("litematlist.header.item"), headerNameX, HEADER_Y + 3, 0xFFFFFFFF);
        ctx.drawString(this.font,
                I18n.tr("litematlist.header.total") + (sortMode == SortMode.TOTAL_DESC || sortMode == SortMode.TOTAL_ASC ? sortMode.arrow : ""),
                colTotalX, HEADER_Y + 3, 0xFFFFFFFF);
        ctx.drawString(this.font,
                I18n.tr("litematlist.header.have") + (sortMode == SortMode.HAVE_DESC || sortMode == SortMode.HAVE_ASC ? sortMode.arrow : ""),
                colHaveX, HEADER_Y + 3, 0xFFFFFFFF);
        ctx.drawString(this.font,
                I18n.tr("litematlist.header.missing") + (sortMode == SortMode.MISS_DESC || sortMode == SortMode.MISS_ASC ? sortMode.arrow : ""),
                colMissX, HEADER_Y + 3, 0xFFFFFFFF);

        // 仅在悬停数值列时显示量级 tooltip
        if (hoveredRow >= 0 && hoveredColumn >= 0 && hoveredRow < displayRows.size()) {
            MaterialRow hovered = displayRows.get(hoveredRow);
            int haveCount = getPlayerItemCount(hovered.item);
            int missCount = Math.max(0, hovered.totalCount - haveCount);

            int tooltipValue = switch (hoveredColumn) {
                case 0 -> hovered.totalCount;
                case 1 -> haveCount;
                case 2 -> missCount;
                default -> hovered.totalCount;
            };

            String[] tooltip = formatCountTooltip(tooltipValue);
            drawCountTooltip(ctx, tooltip, mouseX, mouseY);
        }

        if (displayRows.size() > visibleRows) {
            String scrollInfo = (scrollOffset + 1) + "-" +
                    Math.min(scrollOffset + visibleRows, displayRows.size()) +
                    " / " + displayRows.size();
            ctx.drawCenteredString(this.font,
                    scrollInfo, this.width / 2, listBottom + 5, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean onMouseClicked(MouseButtonEvent event, boolean isDrag) {
        if (super.onMouseClicked(event, isDrag)) return true;

        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();

        if (button == 0) {
            if (mouseY >= HEADER_Y && mouseY <= HEADER_Y + HEADER_HEIGHT) {
                handleHeaderClick(mouseX, mouseY);
                return true;
            }

            // 标记材料点击
            if (allowPin) {
                List<MaterialRow> displayRows = getSortedRows();
                int pinRow = getRowAtY((int)mouseY, displayRows);
                if (pinRow >= 0 && mouseX >= 15 && mouseX <= 31) {
                    MaterialRow row = displayRows.get(pinRow);
                    if (currentPinned.contains(row.originalItem)) {
                        currentPinned.remove(row.originalItem);
                    } else {
                        currentPinned.add(row.originalItem);
                    }
                    savePersistence();
                    initGui();
                    return true;
                }
            }

            // 拖拽检测（仅在启用手动重排时）
            if (Configs.Generic.ALLOW_MANUAL_REORDER.getBooleanValue()) {
                List<MaterialRow> displayRows = getSortedRows();
                int row = getRowAtY((int)mouseY, displayRows);
                if (row >= 0) {
                    // 排除按钮区域
                    if (mouseX >= 10 && mouseX < this.width - 210) {
                        draggedRow = row;
                        dragStartY = (int)mouseY;
                        isDragging = false;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        int mouseY = (int) event.y();
        int button = event.button();

        if (draggedRow >= 0 && button == 0 && Configs.Generic.ALLOW_MANUAL_REORDER.getBooleanValue()) {
            List<MaterialRow> displayRows = getSortedRows();
            int currentRow = getRowAtY(mouseY, displayRows);
            if (currentRow >= 0 && currentRow != draggedRow && Math.abs(mouseY - dragStartY) > 5) {
                // 不允许跨置顶边界拖拽
                if (allowPin) {
                    MaterialRow dragged = displayRows.get(draggedRow);
                    MaterialRow target = displayRows.get(currentRow);
                    boolean draggedPinned = currentPinned.contains(dragged.originalItem);
                    boolean targetPinned = currentPinned.contains(target.originalItem);
                    if (draggedPinned != targetPinned) {
                        return true;
                    }
                }
                isDragging = true;
                // 交换 rows 中的元素
                MaterialRow draggedItem = displayRows.get(draggedRow);
                MaterialRow targetItem = displayRows.get(currentRow);
                int actualDraggedIdx = rows.indexOf(draggedItem);
                int actualTargetIdx = rows.indexOf(targetItem);
                if (actualDraggedIdx >= 0 && actualTargetIdx >= 0) {
                    Collections.swap(rows, actualDraggedIdx, actualTargetIdx);
                    // 更新重排顺序
                    saveReorderedItems();
                    sortMode = SortMode.NONE;
                    initGui();
                }
                draggedRow = currentRow;
                dragStartY = mouseY;
            }
            return true;
        }
        return super.mouseDragged(event, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggedRow >= 0) {
            if (isDragging) {
                saveReorderedItems();
            }
            draggedRow = -1;
            isDragging = false;
            return true;
        }
        return super.mouseReleased(event);
    }

    private int getRowAtY(int mouseY, List<MaterialRow> displayRows) {
        if (mouseY < LIST_TOP) return -1;
        int row = (mouseY - LIST_TOP) / ROW_HEIGHT + scrollOffset;
        if (row >= displayRows.size()) return -1;
        return row;
    }

    private void saveReorderedItems() {
        List<Item> order = new ArrayList<>();
        for (MaterialRow row : rows) {
            if (!currentIgnored.contains(row.item)) {
                order.add(row.originalItem);
            }
        }
        reorderedItems.put(filePath, order);
    }

    private void drawPinIcon(GuiContext ctx, Identifier textureId, int x, int y) {
        Pair<GpuTextureView, GpuSampler> pair = ctx.bindTexture(textureId);
        if (pair == null) return;
        TextureSetup texSetup = TextureSetup.singleTexture(pair.getLeft(), pair.getRight());
        BlitRenderState blit = new BlitRenderState(
                RenderPipelines.GUI_TEXTURED,
                texSetup,
                new Matrix3x2f(),
                x, y, x + PIN_ICON_SIZE, y + PIN_ICON_SIZE,
                0.0f, 1.0f, 0.0f, 1.0f,
                0xFFFFFFFF,
                null
        );
        ctx.addSimpleElementToCurrentLayer(blit);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount,
                                  double verticalAmount) {
        List<MaterialRow> displayRows = getSortedRows();
        if (mouseY >= LIST_TOP && mouseY <= LIST_TOP + visibleRows * ROW_HEIGHT) {
            scrollOffset = Math.max(0, scrollOffset - (int) verticalAmount);
            int maxOffset = Math.max(0, displayRows.size() - visibleRows);
            scrollOffset = Math.min(scrollOffset, maxOffset);
            initGui();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == 256) {
            Minecraft.getInstance().setScreen(parent);
            return true;
        }
        return super.keyPressed(event);
    }

    private record MaterialRow(ItemStack itemStack, String name, int totalCount, Item item, Item originalItem, int missingCount) {}
}