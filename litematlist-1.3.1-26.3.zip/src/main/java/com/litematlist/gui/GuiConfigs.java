package com.litematlist.gui;

import java.util.List;
import com.litematlist.I18n;
import com.litematlist.LitematListMod;
import com.litematlist.config.ConfigGuiTab;
import com.litematlist.config.Configs;
import com.litematlist.config.Hotkeys;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.gui.GuiConfigsBase;
import fi.dy.masa.malilib.gui.button.ButtonBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import fi.dy.masa.malilib.render.GuiContext;

public class GuiConfigs extends GuiConfigsBase
{
    private static ConfigGuiTab currentTab = ConfigGuiTab.GENERIC;

    public GuiConfigs()
    {
        super(10, 50, LitematListMod.MOD_ID, null, "litematlist.gui.title.configs");
    }

    @Override
    public void initGui()
    {
        super.initGui();
        this.clearOptions();

        // 修复首次打开配置菜单时 modSwitchWidget 未显示的问题
        if (this.modSwitchWidget == null) {
            this.buildConfigSwitcher();
        }

        int x = 10;
        int y = 26;

        for (ConfigGuiTab tab : ConfigGuiTab.values())
        {
            x += this.createTabButton(x, y, tab);
        }

        // 右下角「回到主菜单」按钮
        int backBtnY = this.height - 38;
        ButtonGeneric backBtn = new ButtonGeneric(this.width - 130, backBtnY, 120, 20, I18n.tr("litematlist.button.back_to_main"));
        backBtn.setRenderDefaultBackground(true);
        this.addButton(backBtn, (IButtonActionListener) (b, mb) ->
                Minecraft.getInstance().setScreen(new MaterialListScreen()));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor gfx, int mouseX, int mouseY, float partialTicks) {
        GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
        this.extractBackground(gfx, mouseX, mouseY, partialTicks);
        super.extractRenderState(gfx, mouseX, mouseY, partialTicks);

        // 作者署名 —— 放在标题 "LitematList 配置" 后面
        String title = Component.translatable("litematlist.gui.title.configs").getString();
        int titleWidth = this.font.width(title);
        int titleX = 10; // GuiConfigsBase 标题从 x=10 开始
        int titleY = 10;
        int sigX = titleX + titleWidth + 8;
        ctx.drawString(
                this.font, "by  bilibili  命运天S", sigX, titleY, 0xFFFFFFFF);
    }

    private int createTabButton(int x, int y, ConfigGuiTab tab)
    {
        ButtonGeneric button = new ButtonGeneric(x, y, -1, 20, tab.getDisplayName());
        button.setEnabled(currentTab != tab);
        this.addButton(button, new TabButtonListener(tab, this));

        return button.getWidth() + 2;
    }

    @Override
    protected int getConfigWidth()
    {
        return currentTab == ConfigGuiTab.HOTKEYS ? 200 : 140;
    }

    @Override
    protected boolean useKeybindSearch()
    {
        return currentTab == ConfigGuiTab.HOTKEYS;
    }

    @Override
    public List<ConfigOptionWrapper> getConfigs()
    {
        List<? extends IConfigBase> configs = switch (currentTab)
        {
            case GENERIC -> Configs.Generic.OPTIONS;
            case HOTKEYS -> Hotkeys.HOTKEY_LIST;
        };
        return ConfigOptionWrapper.createFor(configs);
    }

    private record TabButtonListener(ConfigGuiTab tab, GuiConfigs gui) implements IButtonActionListener
    {
        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            currentTab = this.tab;
            GuiConfigs newGui = new GuiConfigs();
            newGui.setParent(this.gui.getParent());
            fi.dy.masa.malilib.gui.GuiBase.openGui(newGui);
        }
    }
}