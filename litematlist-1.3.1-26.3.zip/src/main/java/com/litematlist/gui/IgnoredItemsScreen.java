package com.litematlist.gui;

import com.litematlist.I18n;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import fi.dy.masa.malilib.render.GuiContext;

import java.nio.file.Path;
import java.util.*;

/**
 * 已忽略物品列表界面。
 * 显示被忽略的物品及其数量，支持取消忽略，悬停显示量级提示。
 */
public class IgnoredItemsScreen extends GuiBase {

    private final GuiBase parent;
    private final String schematicName;
    private final Path filePath;
    private final Set<Item> ignoredSet;
    private final List<Item> ignoredList;
    private final Map<Item, Integer> ignoredTotals; // 已忽略物品 → 总数
    private int scrollOffset = 0;
    private static final int ROW_HEIGHT = 22;
    private static final int LIST_TOP = 48;
    private int visibleRows;
    private int hoveredRow = -1;

    public IgnoredItemsScreen(GuiBase parent, String schematicName, Path filePath,
                              Set<Item> ignoredSet, Map<Item, Integer> ignoredTotals) {
        super();
        this.parent = parent;
        this.schematicName = schematicName;
        this.filePath = filePath;
        this.ignoredSet = ignoredSet;
        this.ignoredList = new ArrayList<>(ignoredSet);
        this.ignoredTotals = ignoredTotals;
        this.title = I18n.tr("litematlist.title.ignored_items", schematicName);
    }

    @Override
    public void initGui() {
        super.initGui();
        this.visibleRows = (this.height - 100) / ROW_HEIGHT;

        int buttonY = this.height - 38;

        // 返回按钮
        ButtonGeneric backButton = new ButtonGeneric(
                this.width / 2 - 60, buttonY, 120, 20, I18n.tr("litematlist.button.back"));
        backButton.setRenderDefaultBackground(true);
        this.addButton(backButton, (IButtonActionListener) (button, mouseButton) ->
                Minecraft.getInstance().setScreen(parent));

        // 清除全部忽略按钮
        ButtonGeneric clearAllBtn = new ButtonGeneric(
                this.width / 2 + 70, buttonY, 100, 20, I18n.tr("litematlist.button.clear_all_ignored"));
        clearAllBtn.setRenderDefaultBackground(true);
        this.addButton(clearAllBtn, (IButtonActionListener) (b, mb) -> {
            ignoredSet.clear();
            ignoredList.clear();
            initGui();
        });

        createRowButtons();
    }

    private void createRowButtons() {
        int maxIdx = Math.min(ignoredList.size(), scrollOffset + visibleRows);

        for (int i = scrollOffset; i < maxIdx; i++) {
            Item item = ignoredList.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;
            final int rowIdx = i;

            int btnX = this.width - 120;
            ButtonGeneric restoreBtn = new ButtonGeneric(btnX, rowY + 1, 100, 20, I18n.tr("litematlist.button.cancel_ignore"));
            restoreBtn.setRenderDefaultBackground(true);
            this.addButton(restoreBtn, (IButtonActionListener) (b, mb) -> {
                ignoredSet.remove(item);
                ignoredList.remove(rowIdx);
                initGui();
            });
        }
    }

    private String[] formatCountTooltip(int total) {
        int shulker = total / 1728;
        int remainder = total % 1728;
        int stacks = remainder / 64;
        int items = remainder % 64;
        double shulkerFloat = (double) total / 1728.0;
        return new String[] {
            String.format("%d = %d×1728 + %d×64 + %d  |", total, shulker, stacks, items),
            String.format(" = %d×64+%d  |", shulker * 27 + stacks, items),
            String.format(" ≈%.2f 潜影盒  |", shulkerFloat)
        };
    }

    private void drawCountTooltip(GuiContext ctx, String[] lines, int mouseX, int mouseY) {
        int maxW = 0;
        for (String line : lines) {
            maxW = Math.max(maxW, this.font.width(line));
        }
        int lineH = 12;
        int padX = 6;
        int padY = 4;
        int tipW = maxW + padX * 2;
        int tipH = lines.length * lineH + padY * 2;
        int tipX = mouseX + 12;
        int tipY = mouseY - tipH;
        if (tipX + tipW > this.width) tipX = this.width - tipW - 4;
        if (tipY < 4) tipY = mouseY + 16;

        ctx.fill(tipX, tipY, tipX + tipW, tipY + tipH, 0xCC000000);
        ctx.fill(tipX + 1, tipY + 1, tipX + tipW - 1, tipY + tipH - 1, 0xCC333333);
        for (int i = 0; i < lines.length; i++) {
            ctx.drawString(this.font, lines[i], tipX + padX, tipY + padY + i * lineH, 0xFFFFFFFF);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor gfx, int mouseX, int mouseY, float partialTicks) {
        GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
        this.extractBackground(gfx, mouseX, mouseY, partialTicks);

        ctx.drawCenteredString(
                this.font, this.title, this.width / 2, 12, 0xFFFFFFFF);

        // 被忽略物品数量
        String countText = I18n.tr("litematlist.ignored.count", ignoredList.size());
        ctx.drawCenteredString(this.font,
                countText, this.width / 2, 24, 0xFFAAAAAA);

        if (ignoredList.isEmpty()) {
            ctx.drawCenteredString(
                    this.font, I18n.tr("litematlist.ignored.empty"),
                    this.width / 2, this.height / 2 - 10, 0xFFFFFFFF);
            super.extractRenderState(gfx, mouseX, mouseY, partialTicks);
            return;
        }

        // ===== 第1层：背景 =====
        // 表头背景
        ctx.fill(8, 30, this.width - 8, 46, 0x60000000);

        // 列表背景
        int listBottom = LIST_TOP + visibleRows * ROW_HEIGHT;
        ctx.fill(8, LIST_TOP - 2, this.width - 8, listBottom + 2, 0x40000000);

        hoveredRow = -1;
        int maxIdx = Math.min(ignoredList.size(), scrollOffset + visibleRows);
        for (int i = scrollOffset; i < maxIdx; i++) {
            Item item = ignoredList.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;

            if (mouseX >= 10 && mouseX <= this.width - 10
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT) {
                hoveredRow = i;
                ctx.fill(10, rowY, this.width - 10, rowY + ROW_HEIGHT, 0x40FFFFFF);
            } else if ((i - scrollOffset) % 2 == 0) {
                ctx.fill(10, rowY, this.width - 10, rowY + ROW_HEIGHT, 0x10FFFFFF);
            }
        }

        // ===== 第2层：按钮（在背景之上） =====
        super.extractRenderState(gfx, mouseX, mouseY, partialTicks);

        // ===== 第3层：文字和图标（在最上层） =====
        // 表头文字
        ctx.drawString(this.font, I18n.tr("litematlist.header.item"), 35, 33, 0xFFAAAAAA);
        ctx.drawString(this.font, I18n.tr("litematlist.header.total"), 200, 33, 0xFFAAAAAA);

        for (int i = scrollOffset; i < maxIdx; i++) {
            Item item = ignoredList.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;

            ctx.renderItem(new ItemStack(item), 15, rowY + 2);
            ctx.drawString(this.font,
                    item.getName(new ItemStack(item)).getString(), 35, rowY + 5, 0xFFFFFFFF);

            // 显示总数
            int total = ignoredTotals.getOrDefault(item, 0);
            ctx.drawString(this.font, String.valueOf(total), 200, rowY + 5, 0xFFFFFFFF);
        }

        // 悬停量级提示
        if (hoveredRow >= 0 && hoveredRow < ignoredList.size()) {
            Item item = ignoredList.get(hoveredRow);
            int total = ignoredTotals.getOrDefault(item, 0);
            if (total > 0) {
                String[] tooltip = formatCountTooltip(total);
                drawCountTooltip(ctx, tooltip, mouseX, mouseY);
            }
        }

        if (ignoredList.size() > visibleRows) {
            String scrollInfo = (scrollOffset + 1) + "-" +
                    Math.min(scrollOffset + visibleRows, ignoredList.size()) +
                    " / " + ignoredList.size();
            ctx.drawCenteredString(this.font,
                    scrollInfo, this.width / 2, listBottom + 5, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount,
                                  double verticalAmount) {
        if (mouseY >= LIST_TOP && mouseY <= LIST_TOP + visibleRows * ROW_HEIGHT) {
            scrollOffset = Math.max(0, scrollOffset - (int) verticalAmount);
            int maxOffset = Math.max(0, ignoredList.size() - visibleRows);
            scrollOffset = Math.min(scrollOffset, maxOffset);
            initGui();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
}