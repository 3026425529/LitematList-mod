package com.litematlist.gui;

import com.litematlist.LitematicaBridge;
import com.litematlist.LitematListMod;
import com.litematlist.I18n;
import com.litematlist.SchematicPreviewHelper;
import com.litematlist.MaterialListImporter;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.BlitRenderState;
import net.minecraft.resources.Identifier;
import fi.dy.masa.malilib.render.GuiContext;
import org.apache.commons.lang3.tuple.Pair;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.GpuSampler;

import java.nio.file.Path;
import java.util.*;

public class MaterialListScreen extends GuiBase {

    private static final List<LoadedEntry> loadedEntries = new ArrayList<>();

    private int scrollOffset = 0;
    private static final int ROW_HEIGHT = 22;
    private static final int HEADER_TOP = 35;
    private static final int HEADER_HEIGHT = 18;
    private static final int LIST_TOP = HEADER_TOP + HEADER_HEIGHT + 2;
    private static final int PIN_AREA_WIDTH = 22;
    private static final int PIN_ICON_SIZE = 16;
    private static final int PIN_ICON_X = 10;
    private static final int PIN_ICON_Y_OFFSET = 2;
    private int visibleRows;

    // ---- 错误提示 ----
    private static String errorMessage = null;
    private static long errorMessageTime = 0;

    /** 设置错误提示，3 秒后自动消失 */
    public static void setError(String msg) {
        errorMessage = msg;
        errorMessageTime = System.currentTimeMillis();
    }

    // ---- 置顶图标纹理 ----
    private static final Identifier PIN_EMPTY = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/empty.png");
    private static final Identifier PIN_FAVORITE = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/favorite.png");
    private static final Identifier PIN_HOVERED_EMPTY = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/hovered_empty.png");
    private static final Identifier PIN_HOVERED_FAVORITE = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/hovered_favorite.png");
    private static final Identifier PIN_FOCUSED = Identifier.fromNamespaceAndPath("litematlist", "textures/gui/pin/focused_outline.png");

    // ---- 排序 ----
    private enum SortMode { NONE, NAME_ASC, NAME_DESC }
    private SortMode sortMode = SortMode.NONE;

    // ---- 拖拽 ----
    private int draggedIndex = -1;
    private int dragStartY = 0;
    private boolean isDragging = false;

    // ---- "从投影同步"按钮位置（用于 tooltip） ----
    private int syncBtnX, syncBtnY, syncBtnW, syncBtnH;

    // ---- "导入列表文件"和"添加材料列表"按钮位置（用于 tooltip） ----
    private int importBtnX, importBtnY, importBtnW, importBtnH;
    private int addBtnX, addBtnY, addBtnW, addBtnH;

    // ---- 预览按钮位置列表（用于 tooltip） ----
    private final List<PreviewBtnInfo> previewBtnInfos = new ArrayList<>();

    private record PreviewBtnInfo(int x, int y, int w, int h) {}

    public MaterialListScreen() {
        super();
        this.title = I18n.tr("litematlist.title.material_list");
    }

    @Override
    public void initGui() {
        super.initGui();

        int listHeight = this.height - 40 - 5 - LIST_TOP;
        this.visibleRows = listHeight / ROW_HEIGHT;

        int buttonY = this.height - 38;
        int btnW = 80;
        int gap = 5;
        int totalBtnW = 5 * btnW + 4 * gap; // 5 个按钮 + 4 个间隔
        int startX = (this.width - totalBtnW) / 2;

        // 导入列表文件
        importBtnX = startX;
        importBtnY = buttonY;
        importBtnW = btnW;
        importBtnH = 20;
        ButtonGeneric importBtn = new ButtonGeneric(importBtnX, importBtnY, importBtnW, importBtnH, I18n.tr("litematlist.button.import_list_file"));
        importBtn.setRenderDefaultBackground(true);
        this.addButton(importBtn, (IButtonActionListener) (b, mb) -> {
            LitematListMod.LOGGER.info("[MaterialListScreen] 点击「导入列表文件」");
            Minecraft.getInstance().setScreen(new TxtBrowserScreen(this));
        });

        // 添加材料列表
        addBtnX = startX + btnW + gap;
        addBtnY = buttonY;
        addBtnW = btnW;
        addBtnH = 20;
        ButtonGeneric addBtn = new ButtonGeneric(addBtnX, addBtnY, addBtnW, addBtnH, I18n.tr("litematlist.button.add_material_list"));
        addBtn.setRenderDefaultBackground(true);
        this.addButton(addBtn, (IButtonActionListener) (b, mb) -> {
            LitematListMod.LOGGER.info("[MaterialListScreen] 点击「添加材料列表」");
            Minecraft.getInstance().setScreen(new SchematicBrowserScreen(this));
        });

        // 从投影同步（记录按钮位置用于 tooltip 渲染）
        syncBtnX = startX + 2 * (btnW + gap);
        syncBtnY = buttonY;
        syncBtnW = btnW;
        syncBtnH = 20;
        ButtonGeneric syncBtn = new ButtonGeneric(syncBtnX, syncBtnY, syncBtnW, syncBtnH, I18n.tr("litematlist.button.sync_from_projection"));
        syncBtn.setRenderDefaultBackground(true);
        this.addButton(syncBtn, (IButtonActionListener) (b, mb) -> {
            LitematListMod.LOGGER.info("[MaterialListScreen] 点击「从投影同步」");
            syncFromLitematica();
            this.scrollOffset = 0;
            initGui();
        });

        // 关闭
        ButtonGeneric closeBtn = new ButtonGeneric(startX + 3 * (btnW + gap), buttonY, btnW, 20, I18n.tr("litematlist.button.close"));
        closeBtn.setRenderDefaultBackground(true);
        this.addButton(closeBtn, (IButtonActionListener) (b, mb) -> {
            LitematListMod.LOGGER.info("[MaterialListScreen] 点击「关闭」");
            closeGui(true);
        });

        // 配置
        ButtonGeneric configBtn = new ButtonGeneric(startX + 4 * (btnW + gap), buttonY, btnW, 20, I18n.tr("litematlist.button.config"));
        configBtn.setRenderDefaultBackground(true);
        this.addButton(configBtn, (IButtonActionListener) (b, mb) -> {
            LitematListMod.LOGGER.info("[MaterialListScreen] 点击「配置」");
            Minecraft.getInstance().setScreen(new GuiConfigs());
        });

        createRowButtons();
    }

    private void createRowButtons() {
        int visibleRows = this.getVisibleRows();
        int maxIdx = Math.min(loadedEntries.size(), scrollOffset + visibleRows);
        boolean previewAvailable = SchematicPreviewHelper.isAvailable();
        LitematListMod.LOGGER.info("[MaterialListScreen] createRowButtons: previewAvailable={}, entries={}, scrollOffset={}, visibleRows={}",
                previewAvailable, loadedEntries.size(), scrollOffset, visibleRows);

        previewBtnInfos.clear();

        for (int i = scrollOffset; i < maxIdx; i++) {
            LoadedEntry entry = loadedEntries.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;
            final int rowIdx = i;

            int previewBtnW = 70;
            int viewBtnW = 70;
            int removeBtnW = 50;
            int gap = 2;
            int removeX = this.width - 12 - removeBtnW;
            int viewX = removeX - viewBtnW - gap;
            int previewX = viewX - previewBtnW - gap;

            if (previewAvailable && !isTxtEntry(entry) && !isJsonEntry(entry)) {
                ButtonGeneric previewBtn = new ButtonGeneric(previewX, rowY + 1, previewBtnW, 20, I18n.tr("litematlist.button.preview_schematic"));
                previewBtn.setRenderDefaultBackground(true);
                this.addButton(previewBtn, (IButtonActionListener) (b, mb) -> {
                    LitematListMod.LOGGER.info("[MaterialListScreen] 点击「预览原理图」: name={}, path={}", entry.name(), entry.filePath());
                    SchematicPreviewHelper.openFullscreenPreview(this, entry.filePath());
                });
                previewBtnInfos.add(new PreviewBtnInfo(previewX, rowY + 1, previewBtnW, 20));
                LitematListMod.LOGGER.info("[MaterialListScreen] 已添加预览按钮: rowIdx={}, name={}", rowIdx, entry.name());
            } else if (isTxtEntry(entry) || isJsonEntry(entry)) {
                ButtonGeneric renameBtn = new ButtonGeneric(previewX, rowY + 1, previewBtnW, 20, I18n.tr("litematlist.button.rename"));
                renameBtn.setRenderDefaultBackground(true);
                this.addButton(renameBtn, (IButtonActionListener) (b, mb) -> {
                    LitematListMod.LOGGER.info("[MaterialListScreen] 点击「重命名」: name={}", entry.name());
                    Minecraft.getInstance().setScreen(new RenameScreen(this, rowIdx, entry.name()));
                });
            }

            ButtonGeneric viewBtn = new ButtonGeneric(viewX, rowY + 1, viewBtnW, 20, I18n.tr("litematlist.button.view_material_list"));
            viewBtn.setRenderDefaultBackground(true);
            this.addButton(viewBtn, (IButtonActionListener) (b, mb) -> {
                LitematListMod.LOGGER.info("[MaterialListScreen] 点击「查看材料」: name={}, path={}", entry.name(), entry.filePath());
                Minecraft.getInstance().setScreen(
                        new MaterialDetailScreen(this, entry.name(), entry.filePath()));
            });

            ButtonGeneric removeBtn = new ButtonGeneric(removeX, rowY + 1, removeBtnW, 20, I18n.tr("litematlist.button.remove"));
            removeBtn.setRenderDefaultBackground(true);
            this.addButton(removeBtn, (IButtonActionListener) (b, mb) -> {
                LitematListMod.LOGGER.info("[MaterialListScreen] 点击「移除」: name={}, path={}", entry.name(), entry.filePath());
                removeEntry(rowIdx);
                scrollOffset = Math.min(scrollOffset, Math.max(0, loadedEntries.size() - getVisibleRows()));
                initGui();
            });
        }
    }

    private int getVisibleRows() {
        return (this.height - 40 - 5 - LIST_TOP) / ROW_HEIGHT;
    }

    // ==================== 排序 ====================

    private List<LoadedEntry> getDisplayEntries() {
        List<LoadedEntry> entries = new ArrayList<>(loadedEntries);

        // 先按置顶分组
        List<LoadedEntry> pinned = new ArrayList<>();
        List<LoadedEntry> unpinned = new ArrayList<>();
        for (LoadedEntry e : entries) {
            if (e.pinned) pinned.add(e);
            else unpinned.add(e);
        }

        // 组内排序
        if (sortMode == SortMode.NAME_ASC) {
            pinned.sort(Comparator.comparing(LoadedEntry::name, String.CASE_INSENSITIVE_ORDER));
            unpinned.sort(Comparator.comparing(LoadedEntry::name, String.CASE_INSENSITIVE_ORDER));
        } else if (sortMode == SortMode.NAME_DESC) {
            pinned.sort(Comparator.comparing(LoadedEntry::name, String.CASE_INSENSITIVE_ORDER).reversed());
            unpinned.sort(Comparator.comparing(LoadedEntry::name, String.CASE_INSENSITIVE_ORDER).reversed());
        }

        // 合并：置顶在前
        pinned.addAll(unpinned);
        return pinned;
    }

    private void cycleSortMode() {
        switch (sortMode) {
            case NONE -> sortMode = SortMode.NAME_ASC;
            case NAME_ASC -> sortMode = SortMode.NAME_DESC;
            case NAME_DESC -> sortMode = SortMode.NONE;
        }
        LitematListMod.LOGGER.info("[MaterialListScreen] 排序模式切换为: {}", sortMode);

        // 应用排序到 loadedEntries
        if (sortMode != SortMode.NONE) {
            List<LoadedEntry> sorted = getDisplayEntries();
            loadedEntries.clear();
            loadedEntries.addAll(sorted);
        }
        // NONE 模式保持当前顺序（可能被拖拽修改过）
        scrollOffset = 0;
        initGui();
    }

    // ==================== 置顶 ====================

    private void togglePin(int index) {
        if (index < 0 || index >= loadedEntries.size()) return;
        LoadedEntry entry = loadedEntries.get(index);
        entry.pinned = !entry.pinned;
        LitematListMod.LOGGER.info("[MaterialListScreen] 置顶切换: name={}, pinned={}", entry.name(), entry.pinned);

        // 始终重新排序，确保置顶项在前
        List<LoadedEntry> sorted = getDisplayEntries();
        loadedEntries.clear();
        loadedEntries.addAll(sorted);
        MaterialDetailScreen.savePersistence();
        initGui();
    }

    // ==================== 拖拽重排 ====================

    private int getRowAtY(int mouseY) {
        if (mouseY < LIST_TOP) return -1;
        int row = (mouseY - LIST_TOP) / ROW_HEIGHT + scrollOffset;
        if (row >= loadedEntries.size()) return -1;
        return row;
    }

    private boolean isInPinArea(int mouseX) {
        return mouseX >= PIN_ICON_X && mouseX <= PIN_ICON_X + PIN_ICON_SIZE;
    }

    @Override
    public boolean onMouseClicked(MouseButtonEvent event, boolean isDrag) {
        if (super.onMouseClicked(event, isDrag)) return true;

        int mouseX = (int) event.x();
        int mouseY = (int) event.y();
        int button = event.button();

        if (button == 0) { // 左键
            // 检测表头点击
            if (mouseY >= HEADER_TOP && mouseY <= HEADER_TOP + HEADER_HEIGHT) {
                LitematListMod.LOGGER.info("[MaterialListScreen] 点击表头「原理图名称」");
                cycleSortMode();
                return true;
            }

            // 检测置顶区域点击
            int row = getRowAtY(mouseY);
            if (row >= 0 && isInPinArea(mouseX)) {
                togglePin(row);
                return true;
            }

            // 检测列表区域拖拽（非按钮区域，非置顶区域）
            if (row >= 0 && mouseX >= 10 + PIN_AREA_WIDTH && mouseX < this.width - 210) {
                draggedIndex = row;
                dragStartY = mouseY;
                isDragging = false;
                LitematListMod.LOGGER.info("[MaterialListScreen] 开始拖拽: row={}, name={}", row, loadedEntries.get(row).name());
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        int mouseY = (int) event.y();
        int button = event.button();

        if (draggedIndex >= 0 && button == 0) {
            int currentRow = getRowAtY(mouseY);
            if (currentRow >= 0 && currentRow != draggedIndex && Math.abs(mouseY - dragStartY) > 5) {
                // 防止跨置顶边界拖拽：置顶项不能拖到非置顶项下方，反之亦然
                LoadedEntry dragged = loadedEntries.get(draggedIndex);
                LoadedEntry target = loadedEntries.get(currentRow);
                if (dragged.pinned != target.pinned) {
                    return true; // 不允许跨边界交换
                }
                isDragging = true;
                Collections.swap(loadedEntries, draggedIndex, currentRow);
                LitematListMod.LOGGER.info("[MaterialListScreen] 拖拽交换: {} <-> {}", draggedIndex, currentRow);
                draggedIndex = currentRow;
                dragStartY = mouseY;
                sortMode = SortMode.NONE;
                initGui();
            }
            return true;
        }
        return super.mouseDragged(event, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggedIndex >= 0) {
            LitematListMod.LOGGER.info("[MaterialListScreen] 拖拽结束: draggedIndex={}, isDragging={}", draggedIndex, isDragging);
            draggedIndex = -1;
            isDragging = false;
            return true;
        }
        return super.mouseReleased(event);
    }

    /**
     * 添加条目（手动添加，fromLitematica = false）。
     */
    public static void addEntry(String name, Path filePath) {
        addEntry(name, filePath, false);
    }

    static void addEntry(String name, Path filePath, boolean fromLitematica) {
        boolean exists = loadedEntries.stream().anyMatch(e -> e.filePath().equals(filePath));
        if (!exists) {
            loadedEntries.add(new LoadedEntry(name, filePath, fromLitematica));
            LitematListMod.LOGGER.info("已添加材料列表: {} (fromLitematica={})", name, fromLitematica);
            MaterialDetailScreen.savePersistence();
        }
    }

    /** 内部使用：添加条目并指定置顶状态（用于持久化加载） */
    public static void addEntryInternal(String name, Path filePath, boolean fromLitematica, boolean pinned) {
        boolean exists = loadedEntries.stream().anyMatch(e -> e.filePath().equals(filePath));
        if (!exists) {
            LoadedEntry entry = new LoadedEntry(name, filePath, fromLitematica);
            entry.pinned = pinned;
            loadedEntries.add(entry);
            LitematListMod.LOGGER.info("已添加材料列表: {} (fromLitematica={}, pinned={})", name, fromLitematica, pinned);
        }
    }

    /** 获取所有已加载条目（供持久化使用） */
    public static List<LoadedEntry> getLoadedEntries() {
        return new ArrayList<>(loadedEntries);
    }

    private void syncFromLitematica() {
        LitematListMod.LOGGER.info("[MaterialListScreen] 开始从投影同步...");
        if (!LitematicaBridge.isAvailable()) {
            LitematListMod.LOGGER.warn("[MaterialListScreen] Litematica 不可用，跳过同步");
            return;
        }

        List<LitematicaBridge.SchematicInfo> litematicaList = LitematicaBridge.getLoadedSchematics();
        LitematListMod.LOGGER.info("[MaterialListScreen] 从投影获取到 {} 个已加载原理图", litematicaList.size());
        Set<Path> loadedPaths = new HashSet<>();
        for (LitematicaBridge.SchematicInfo info : litematicaList) {
            if (info.filePath() != null) {
                loadedPaths.add(info.filePath());
                addEntry(info.name(), info.filePath(), true);
            }
        }

        loadedEntries.removeIf(entry ->
                entry.fromLitematica() && !loadedPaths.contains(entry.filePath()));
        MaterialDetailScreen.savePersistence();
        LitematListMod.LOGGER.info("[MaterialListScreen] 同步完成，当前共 {} 个条目", loadedEntries.size());
    }

    // ==================== 渲染 ====================

    @Override
    public void extractRenderState(GuiGraphicsExtractor gfx, int mouseX, int mouseY, float partialTicks) {
        GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
        this.extractBackground(gfx, mouseX, mouseY, partialTicks);

        drawListBackground(ctx);
        drawHeader(ctx, mouseX, mouseY);
        super.extractRenderState(gfx, mouseX, mouseY, partialTicks);
        drawListContent(ctx, mouseX, mouseY);
        drawHeaderText(ctx); // 表头文字在最顶层
        drawSyncTooltip(ctx, mouseX, mouseY);
        drawImportBtnTooltip(ctx, mouseX, mouseY);
        drawAddBtnTooltip(ctx, mouseX, mouseY);
        drawPreviewTooltip(ctx, mouseX, mouseY);
        drawPinTooltip(ctx, mouseX, mouseY);
    }

    private void drawHeader(GuiContext ctx, int mouseX, int mouseY) {
        // 表头背景
        ctx.fill(10, HEADER_TOP, this.width - 10, HEADER_TOP + HEADER_HEIGHT, 0x60000000);

        boolean hovered = mouseY >= HEADER_TOP && mouseY <= HEADER_TOP + HEADER_HEIGHT;
        if (hovered) {
            ctx.fill(10, HEADER_TOP, this.width - 10, HEADER_TOP + HEADER_HEIGHT, 0x30FFFFFF);
        }
    }

    private void drawHeaderText(GuiContext ctx) {
        String fullText = I18n.tr("litematlist.header.name") + switch (sortMode) {
            case NAME_ASC -> "  ▲";
            case NAME_DESC -> "  ▼";
            case NONE -> "  ⇅";
        };
        ctx.drawString(this.font, fullText, 34, HEADER_TOP + 5, 0xFFFFFFFF);
    }

    private void drawListBackground(GuiContext ctx) {
        int visibleRows = this.getVisibleRows();
        int listBottom = LIST_TOP + visibleRows * ROW_HEIGHT;
        // 透光性更强的背景
        ctx.fill(8, LIST_TOP - 2, this.width - 8, listBottom + 2, 0x40000000);

        int maxIdx = Math.min(loadedEntries.size(), scrollOffset + visibleRows);
        for (int i = scrollOffset; i < maxIdx; i++) {
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;
            int color = (i == draggedIndex && isDragging) ? 0x60FFFF00 :
                    ((i - scrollOffset) % 2 == 0) ? 0x20FFFFFF : 0x10FFFFFF;
            ctx.fill(10, rowY, this.width - 10, rowY + ROW_HEIGHT, color);
        }
    }

    private void drawListContent(GuiContext ctx, int mouseX, int mouseY) {
        drawCenteredText(ctx, this.title, this.width / 2, 12, 0xFFFFFFFF);
        drawCenteredText(ctx,
                "共 " + loadedEntries.size() + " 个已加载的材料列表", this.width / 2, 24, 0xFFFFFFFF);

        // 错误提示（红字，3秒后消失）
        if (errorMessage != null) {
            if (System.currentTimeMillis() - errorMessageTime > 3000) {
                errorMessage = null;
            } else {
                drawCenteredText(ctx, errorMessage, this.width / 2, this.height - 56, 0xFFFF5555);
            }
        }

        if (loadedEntries.isEmpty()) {
            drawCenteredText(ctx,
                    "暂无已加载的材料列表，请点击 [添加材料列表] 选择原理图",
                    this.width / 2, this.height / 2 - 10, 0xFFFFFFFF);
            return;
        }

        int visibleRows = this.getVisibleRows();
        int maxIdx = Math.min(loadedEntries.size(), scrollOffset + visibleRows);
        // 按钮区域起始位置（与 createRowButtons 中的按钮布局对齐）
        int buttonAreaStart = this.width - 210;
        for (int i = scrollOffset; i < maxIdx; i++) {
            if (i >= loadedEntries.size()) break;
            LoadedEntry entry = loadedEntries.get(i);
            int rowY = LIST_TOP + (i - scrollOffset) * ROW_HEIGHT;

            // 行悬停高亮（名称区域，不含按钮）
            boolean rowHovered = mouseX >= 10 && mouseX <= buttonAreaStart
                    && mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;
            if (rowHovered) {
                ctx.fill(10, rowY, buttonAreaStart, rowY + ROW_HEIGHT, 0x40FFFFFF);
            }

            // 置顶指示器 - 纹理图标
            int pinX = PIN_ICON_X;
            int pinY = rowY + PIN_ICON_Y_OFFSET;
            boolean pinHovered = mouseX >= pinX && mouseX <= pinX + PIN_ICON_SIZE
                    && mouseY >= pinY && mouseY <= pinY + PIN_ICON_SIZE;

            Identifier pinTexture;
            if (entry.pinned) {
                pinTexture = pinHovered ? PIN_HOVERED_FAVORITE : PIN_FAVORITE;
            } else {
                pinTexture = pinHovered ? PIN_HOVERED_EMPTY : PIN_EMPTY;
            }
            drawPinIcon(ctx, pinTexture, pinX, pinY);

            // 聚焦外框：悬停时叠加显示
            if (pinHovered) {
                drawPinIcon(ctx, PIN_FOCUSED, pinX, pinY);
            }

            // 原理图名称
            String displayName = entry.name();
            if (isTxtEntry(entry)) {
                displayName = displayName + "（txt）";
            } else if (isJsonEntry(entry)) {
                displayName = displayName + "（JSON）";
            }
            int maxNameWidth = this.width - 230;
            if (this.font.width(displayName) > maxNameWidth) {
                displayName = this.font.plainSubstrByWidth(displayName, maxNameWidth - 10) + "...";
            }
            ctx.drawString(this.font, displayName, 34, rowY + 5, 0xFFFFFFFF);
        }

        if (loadedEntries.size() > visibleRows) {
            int listBottom = LIST_TOP + visibleRows * ROW_HEIGHT;
            String scrollInfo = (scrollOffset + 1) + "-" +
                    Math.min(scrollOffset + visibleRows, loadedEntries.size()) + " / " + loadedEntries.size();
            drawCenteredText(ctx, scrollInfo, this.width / 2, listBottom + 5, 0xFFFFFFFF);
        }
    }

    /** 绘制"从投影同步"按钮的悬停提示 */
    private void drawSyncTooltip(GuiContext ctx, int mouseX, int mouseY) {
        if (mouseX >= syncBtnX && mouseX <= syncBtnX + syncBtnW &&
                mouseY >= syncBtnY && mouseY <= syncBtnY + syncBtnH) {
            String tip = "从已加载原理图同步";
            drawTooltipBox(ctx, tip, mouseX, mouseY);
        }
    }

    /** 绘制"导入列表文件"按钮的悬停提示 */
    private void drawImportBtnTooltip(GuiContext ctx, int mouseX, int mouseY) {
        if (mouseX >= importBtnX && mouseX <= importBtnX + importBtnW &&
                mouseY >= importBtnY && mouseY <= importBtnY + importBtnH) {
            drawTooltipBox(ctx, I18n.tr("litematlist.tooltip.import_list_file"), mouseX, mouseY);
        }
    }

    /** 绘制"添加材料列表"按钮的悬停提示 */
    private void drawAddBtnTooltip(GuiContext ctx, int mouseX, int mouseY) {
        if (mouseX >= addBtnX && mouseX <= addBtnX + addBtnW &&
                mouseY >= addBtnY && mouseY <= addBtnY + addBtnH) {
            drawTooltipBox(ctx, I18n.tr("litematlist.tooltip.add_material_list"), mouseX, mouseY);
        }
    }

    /** 绘制"预览原理图"按钮的悬停提示 */
    private void drawPreviewTooltip(GuiContext ctx, int mouseX, int mouseY) {
        for (PreviewBtnInfo info : previewBtnInfos) {
            if (mouseX >= info.x && mouseX <= info.x + info.w &&
                    mouseY >= info.y && mouseY <= info.y + info.h) {
                drawTooltipBox(ctx, I18n.tr("litematlist.tooltip.fullscreen_preview") + " (ESC)", mouseX, mouseY);
                return;
            }
        }
    }

    /** 绘制置顶图标的悬停提示 */
    private void drawPinTooltip(GuiContext ctx, int mouseX, int mouseY) {
        int row = getRowAtY(mouseY);
        if (row >= 0 && row < loadedEntries.size() && isInPinArea(mouseX)) {
            LoadedEntry entry = loadedEntries.get(row);
            String tip = entry.pinned ? I18n.tr("litematlist.tooltip.unpin") : I18n.tr("litematlist.tooltip.pin");
            drawTooltipBox(ctx, tip, mouseX, mouseY);
        }
    }

    private void drawTooltipBox(GuiContext ctx, String tip, int mouseX, int mouseY) {
        int tipW = this.font.width(tip) + 8;
        int tipH = 16;
        int tipX = mouseX + 12;
        int tipY = mouseY - 20;
        if (tipX + tipW > this.width) tipX = this.width - tipW - 4;
        if (tipY < 4) tipY = mouseY + 16;

        ctx.fill(tipX, tipY, tipX + tipW, tipY + tipH, 0xCC000000);
        ctx.fill(tipX + 1, tipY + 1, tipX + tipW - 1, tipY + tipH - 1, 0xCC333333);
        ctx.drawString(this.font, tip, tipX + 4, tipY + 4, 0xFFFFFFFF);
    }

    private void drawPinIcon(GuiContext ctx, Identifier textureId, int x, int y) {
        Pair<GpuTextureView, GpuSampler> pair = ctx.bindTexture(textureId);
        if (pair == null) return;
        TextureSetup texSetup = TextureSetup.singleTexture(pair.getLeft(), pair.getRight());
        BlitRenderState blit = new BlitRenderState(
                RenderPipelines.GUI_TEXTURED,
                texSetup,
                new org.joml.Matrix3x2f(),
                x, y, x + PIN_ICON_SIZE, y + PIN_ICON_SIZE,
                0.0f, 1.0f, 0.0f, 1.0f,
                0xFFFFFFFF,
                null
        );
        ctx.addSimpleElementToCurrentLayer(blit);
    }

    private void drawCenteredText(GuiContext ctx, String text, int centerX, int y, int color) {
        int width = this.font.width(text);
        ctx.drawString(this.font, text, centerX - width / 2, y, color);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int visibleRows = this.getVisibleRows();
        if (mouseY >= LIST_TOP && mouseY <= LIST_TOP + visibleRows * ROW_HEIGHT) {
            scrollOffset = Math.max(0, scrollOffset - (int) verticalAmount);
            int maxOffset = Math.max(0, loadedEntries.size() - visibleRows);
            scrollOffset = Math.min(scrollOffset, maxOffset);
            initGui();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public static class LoadedEntry {
        private final String name;
        private final Path filePath;
        private final boolean fromLitematica;
        boolean pinned;

        public LoadedEntry(String name, Path filePath, boolean fromLitematica) {
            this.name = name;
            this.filePath = filePath;
            this.fromLitematica = fromLitematica;
            this.pinned = false;
        }

        public String name() { return name; }
        public Path filePath() { return filePath; }
        public boolean fromLitematica() { return fromLitematica; }
    }

    private static boolean isTxtEntry(LoadedEntry entry) {
        return entry.filePath().getFileName().toString().toLowerCase().endsWith(".txt");
    }

    private static boolean isJsonEntry(LoadedEntry entry) {
        return entry.filePath().getFileName().toString().toLowerCase().endsWith(".json");
    }

    /** 移除条目并清理其持久化数据（替换、忽略） */
    private void removeEntry(int index) {
        if (index < 0 || index >= loadedEntries.size()) return;
        LoadedEntry entry = loadedEntries.remove(index);
        MaterialDetailScreen.cleanupPathData(entry.filePath());
        MaterialDetailScreen.savePersistence();
    }

    /** 重命名条目 */
    public static void renameEntry(int index, String newName) {
        if (index < 0 || index >= loadedEntries.size()) return;
        LoadedEntry old = loadedEntries.get(index);
        LoadedEntry renamed = new LoadedEntry(newName, old.filePath(), old.fromLitematica());
        renamed.pinned = old.pinned; // 保留置顶状态
        loadedEntries.set(index, renamed);
        MaterialDetailScreen.savePersistence();
        LitematListMod.LOGGER.info("[MaterialListScreen] 重命名: '{}' -> '{}'", old.name(), newName);
    }
}