package com.litematlist.gui;

import com.litematlist.I18n;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.button.ButtonGeneric;
import fi.dy.masa.malilib.gui.button.IButtonActionListener;
import fi.dy.masa.malilib.render.GuiContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

/**
 * 重命名界面 —— 允许玩家修改 txt 材料列表条目的显示名称。
 */
public class RenameScreen extends GuiBase {

    private final GuiBase parent;
    private final int entryIndex;
    private final String currentName;
    private EditBox textField;

    public RenameScreen(GuiBase parent, int entryIndex, String currentName) {
        super();
        this.parent = parent;
        this.entryIndex = entryIndex;
        this.currentName = currentName;
        this.title = I18n.tr("litematlist.title.rename");
    }

    @Override
    public void initGui() {
        super.initGui();

        int fieldWidth = 300;
        int fieldX = this.width / 2 - fieldWidth / 2;
        int fieldY = this.height / 2 - 20;

        this.textField = new EditBox(this.font, fieldX, fieldY, fieldWidth, 20, Component.empty());
        this.textField.setValue(this.currentName);
        this.textField.setMaxLength(100);
        this.textField.moveCursorToEnd(false);
        this.textField.setBordered(false);
        this.addRenderableWidget(this.textField);

        int buttonY = this.height - 38;

        ButtonGeneric confirmBtn = new ButtonGeneric(this.width / 2 - 85, buttonY, 80, 20,
                I18n.tr("litematlist.button.confirm"));
        confirmBtn.setRenderDefaultBackground(true);
        this.addButton(confirmBtn, (IButtonActionListener) (b, mb) -> confirmRename());

        ButtonGeneric cancelBtn = new ButtonGeneric(this.width / 2 + 5, buttonY, 80, 20,
                I18n.tr("litematlist.button.cancel"));
        cancelBtn.setRenderDefaultBackground(true);
        this.addButton(cancelBtn, (IButtonActionListener) (b, mb) ->
                Minecraft.getInstance().setScreen(new MaterialListScreen()));
    }

    private void confirmRename() {
        String newName = this.textField.getValue().trim();
        if (!newName.isEmpty()) {
            MaterialListScreen.renameEntry(this.entryIndex, newName);
        }
        Minecraft.getInstance().setScreen(new MaterialListScreen());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor gfx, int mouseX, int mouseY, float partialTicks) {
        GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
        this.extractBackground(gfx, mouseX, mouseY, partialTicks);
        super.extractRenderState(gfx, mouseX, mouseY, partialTicks);

        if (this.textField != null) {
            // 半透明文本框背景（不透明度降低 70%）
            ctx.fill(this.textField.getX() - 1, this.textField.getY() - 1,
                    this.textField.getX() + this.textField.getWidth() + 1,
                    this.textField.getY() + this.textField.getHeight() + 1, 0x4D000000);
            ctx.fill(this.textField.getX(), this.textField.getY(),
                    this.textField.getX() + this.textField.getWidth(),
                    this.textField.getY() + this.textField.getHeight(), 0x4D333333);

            // 完全手动渲染白色文字，不调用 textField.render() 避免黑色文字重叠
            String text = this.textField.getValue();
            int textX = this.textField.getX() + 4;
            int textY = this.textField.getY() + (this.textField.getHeight() - 8) / 2;
            ctx.drawString(this.font, text, textX, textY, 0xFFFFFFFF);

            // 手动绘制光标（闪烁）
            if (this.textField.isFocused() && System.currentTimeMillis() % 1000 < 500) {
                int cursorPos = this.textField.getCursorPosition();
                String beforeCursor = text.substring(0, Math.min(cursorPos, text.length()));
                int cursorX = textX + this.font.width(beforeCursor);
                ctx.fill(cursorX, this.textField.getY() + 2,
                        cursorX + 1, this.textField.getY() + this.textField.getHeight() - 2, 0xFFFFFFFF);
            }
        }
    }

    @Override
    public void removed() {
        super.removed();
        if (this.textField != null) {
            this.textField.setFocused(false);
        }
    }
}