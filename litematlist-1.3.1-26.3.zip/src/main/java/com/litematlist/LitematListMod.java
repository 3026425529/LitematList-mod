package com.litematlist;

import com.litematlist.config.Configs;
import com.litematlist.config.Hotkeys;
import com.litematlist.gui.MaterialDetailScreen;
import com.litematlist.gui.MaterialListScreen;
import fi.dy.masa.malilib.config.ConfigManager;
import fi.dy.masa.malilib.event.InitializationHandler;
import fi.dy.masa.malilib.event.InputEventHandler;
import fi.dy.masa.malilib.hotkeys.*;
import fi.dy.masa.malilib.interfaces.IInitializationHandler;
import fi.dy.masa.malilib.registry.Registry;
import fi.dy.masa.malilib.render.GuiContext;
import fi.dy.masa.malilib.util.data.ModInfo;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

public class LitematListMod implements ClientModInitializer, IInitializationHandler, IKeybindProvider {

    public static final String MOD_ID = "litematlist";
    public static final String MOD_NAME = "LitematList";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("LitematListMod 正在初始化...");

        // 创建 litemalist 文件夹（用于存放导入的 txt 材料列表）
        try {
            Path litemalistDir = Minecraft.getInstance().gameDirectory.toPath().resolve("litemalist");
            if (!Files.exists(litemalistDir)) {
                Files.createDirectories(litemalistDir);
                LOGGER.info("已创建 litemalist 文件夹: {}", litemalistDir);
            }
        } catch (Exception e) {
            LOGGER.error("创建 litemalist 文件夹失败", e);
        }

        // 加载持久化数据（替换映射和忽略物品）
        MaterialDetailScreen.initPersistence();

        InitializationHandler.getInstance().registerInitializationHandler(this);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (Hotkeys.OPEN_MAIN_GUI.getKeybind().isPressed()) {
                Minecraft.getInstance().setScreen(new MaterialListScreen());
            }
        });

        // 全屏预览时在顶部渲染「按 ESC 退出」提示
        ScreenEvents.BEFORE_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen.getClass().getName().contains("GuiSchematicPreviewFullscreen")) {
                ScreenEvents.afterExtract(screen).register((s, gfx, mouseX, mouseY, tickDelta) -> {
                    if (!Configs.Generic.SHOW_ESC_HINT.getBooleanValue()) {
                        return;
                    }
                    GuiContext ctx = GuiContext.fromGuiGraphics(gfx);
                    String hint = I18n.tr("litematlist.hint.press_esc_to_exit");
                    int textW = Minecraft.getInstance().font.width(hint);
                    int x = (screen.width - textW) / 2;
                    int y = 6;
                    ctx.fill(0, 0, screen.width, 22, 0x80000000);
                    ctx.drawString(Minecraft.getInstance().font, hint, x, y, 0xFFFFFF00);
                });
            }
        });

        LOGGER.info("LitematListMod 初始化完成!");
    }

    @Override
    public void registerModHandlers() {
        ConfigManager.getInstance().registerConfigHandler(MOD_ID, new Configs());
        Registry.CONFIG_SCREEN.registerConfigScreenFactory(
                new ModInfo(MOD_ID, MOD_NAME, () -> new MaterialListScreen())
        );
        InputEventHandler.getKeybindManager().registerKeybindProvider(this);
        LOGGER.info("LitematListMod 已注册 MaLib 处理器（Config + ConfigScreen + Keybind）");
    }

    @Override
    public void addKeysToMap(IKeybindManager manager) {
        for (IHotkey hotkey : Hotkeys.HOTKEY_LIST) {
            manager.addKeybindToMap(hotkey.getKeybind());
        }
    }

    @Override
    public void addHotkeys(IKeybindManager manager) {
        manager.addHotkeysForCategory(MOD_NAME, "litematlist.hotkeys.category.main", Hotkeys.HOTKEY_LIST);
    }
}