package com.litematlist;

import fi.dy.masa.malilib.util.nbt.NbtUtils;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

import java.nio.file.Path;
import java.util.*;

/**
 * 读取和解析 .litematic 文件，提取方块状态并统计每种方块对应的物品及数量。
 * 参照 Litematica 0.24.9 的 LitematicaSchematic 源码实现。
 * 支持 Litematica 原生格式（long[] BlockStates）和 Sponge 格式（byte[] BlockData）。
 */
public class LitematicReader {

    public record MaterialEntry(Item item, String blockName, int totalCount) {
        public ItemStack toItemStack() {
            return new ItemStack(item, totalCount);
        }
    }

    /**
     * 从文件路径加载材料列表。
     */
    public static List<MaterialEntry> loadMaterialList(Path filePath) {
        LitematListMod.LOGGER.info("正在解析原理图: {}", filePath.toAbsolutePath());

        try {
            CompoundTag rootTag = NbtUtils.readNbtFromFileAsPath(filePath);
            if (rootTag == null) {
                LitematListMod.LOGGER.error("读取 NBT 失败: {}", filePath);
                return Collections.emptyList();
            }
            LitematListMod.LOGGER.info("成功读取 NBT，顶层键: {}", rootTag.keySet());
            return parseBlockStates(rootTag, filePath);
        } catch (Exception e) {
            LitematListMod.LOGGER.error("解析原理图异常: {}", filePath, e);
            return Collections.emptyList();
        }
    }

    private static List<MaterialEntry> parseBlockStates(CompoundTag rootTag, Path filePath) {
        Map<Item, Integer> itemCounts = new LinkedHashMap<>();
        Map<Item, String> itemNames = new LinkedHashMap<>();
        int regionCount = 0;
        int failedRegions = 0;

        // 检查 Version
        if (!rootTag.contains("Version")) {
            LitematListMod.LOGGER.warn("缺少 Version 字段，不是有效的 Litematica 原理图");
            return Collections.emptyList();
        }
        int version = rootTag.getInt("Version").orElse(-1);
        LitematListMod.LOGGER.info("原理图版本: {}", version);

        // 读取 Regions（Litematica 原生格式）
        Optional<CompoundTag> regionsOpt = rootTag.getCompound("Regions");
        if (regionsOpt.isPresent()) {
            CompoundTag regions = regionsOpt.get();
            LitematListMod.LOGGER.info("找到 Regions，共 {} 个子区域", regions.keySet().size());

            for (String regionName : regions.keySet()) {
                Optional<CompoundTag> regionOpt = regions.getCompound(regionName);
                if (regionOpt.isPresent()) {
                    try {
                        parseRegion(regionOpt.get(), itemCounts, itemNames, regionName, version);
                        regionCount++;
                    } catch (Exception e) {
                        failedRegions++;
                        LitematListMod.LOGGER.error("解析 Region '{}' 失败，跳过该区域: {}", regionName, e.getMessage());
                        LitematListMod.LOGGER.debug("Region '{}' 异常详情:", regionName, e);
                    }
                }
            }
        }

        // 尝试 Sponge 格式（Blocks 键）
        if (regionCount == 0 && rootTag.contains("Blocks")) {
            LitematListMod.LOGGER.info("尝试解析 Sponge 格式...");
            try {
                parseSpongeFormat(rootTag, itemCounts, itemNames);
                regionCount++;
            } catch (Exception e) {
                LitematListMod.LOGGER.error("Sponge 格式解析失败: {}", e.getMessage());
            }
        }

        LitematListMod.LOGGER.info("解析了 {} 个 Region，失败 {} 个，共 {} 种方块",
                regionCount, failedRegions, itemCounts.size());

        List<MaterialEntry> result = new ArrayList<>();
        for (Map.Entry<Item, Integer> entry : itemCounts.entrySet()) {
            Item item = entry.getKey();
            result.add(new MaterialEntry(item, itemNames.getOrDefault(item, item.getName(new ItemStack(item)).getString()), entry.getValue()));
        }
        result.sort((a, b) -> Integer.compare(b.totalCount(), a.totalCount()));
        return result;
    }

    /**
     * 解析 Sponge 格式（byte[] BlockData + CompoundTag Palette）。
     */
    private static void parseSpongeFormat(CompoundTag rootTag, Map<Item, Integer> itemCounts,
                                          Map<Item, String> itemNames) {
        // 读取尺寸（使用绝对值以防负数）
        short width = (short) Math.abs(rootTag.getShort("Width").orElse((short) 0));
        short height = (short) Math.abs(rootTag.getShort("Height").orElse((short) 0));
        short length = (short) Math.abs(rootTag.getShort("Length").orElse((short) 0));
        int totalBlocks = width * height * length;
        LitematListMod.LOGGER.info("Sponge 格式尺寸: {}x{}x{} ({} 方块)", width, height, length, totalBlocks);

        // 读取 Palette（CompoundTag 格式，key=blockStateString, value=index）
        Optional<CompoundTag> paletteOpt = rootTag.getCompound("Palette");
        if (paletteOpt.isEmpty()) {
            LitematListMod.LOGGER.warn("Sponge 格式缺少 Palette");
            return;
        }
        CompoundTag palette = paletteOpt.get();
        int paletteSize = palette.keySet().size();
        LitematListMod.LOGGER.info("Sponge 调色板大小: {}", paletteSize);

        // 解析调色板：index -> BlockState
        List<BlockState> paletteStates = new ArrayList<>(paletteSize);
        for (int i = 0; i < paletteSize; i++) {
            paletteStates.add(Blocks.AIR.defaultBlockState());
        }
        for (String key : palette.keySet()) {
            int index = palette.getInt(key).orElse(-1);
            if (index >= 0 && index < paletteSize) {
                try {
                    BlockState state = parseSpongePaletteEntry(key, index);
                    paletteStates.set(index, state);
                } catch (Exception e) {
                    LitematListMod.LOGGER.warn("Sponge 调色板条目 '{}' 解析失败: {}", key, e.getMessage());
                }
            }
        }

        // 读取 BlockData（byte[]，可变长度整数编码）
        Optional<byte[]> blockDataOpt = rootTag.getByteArray("BlockData");
        if (blockDataOpt.isEmpty()) {
            LitematListMod.LOGGER.warn("Sponge 格式缺少 BlockData");
            return;
        }
        byte[] blockData = blockDataOpt.get();
        LitematListMod.LOGGER.info("Sponge BlockData 大小: {} 字节", blockData.length);

        // 解码可变长度整数
        int bitsPerBlock = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
        int[] decoded = decodeVarIntArray(blockData);

        int decodedBlocks = 0;
        for (int index : decoded) {
            if (decodedBlocks >= totalBlocks) break;
            if (index >= 0 && index < paletteStates.size()) {
                BlockState state = paletteStates.get(index);
                if (!state.isAir()) {
                    Item item = state.getBlock().asItem();
                    if (item != Items.AIR) {
                        itemCounts.merge(item, 1, Integer::sum);
                        itemNames.putIfAbsent(item, state.getBlock().getName().getString());
                    }
                }
            }
            decodedBlocks++;
        }
        LitematListMod.LOGGER.info("Sponge 格式解码了 {} 个方块", decodedBlocks);
    }

    /**
     * 解码可变长度整数数组（Sponge 格式）。
     */
    private static int[] decodeVarIntArray(byte[] data) {
        List<Integer> result = new ArrayList<>();
        int i = 0;
        while (i < data.length) {
            int value = 0;
            int shift = 0;
            byte b;
            do {
                if (i >= data.length) break;
                b = data[i++];
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0);
            result.add(value);
        }
        int[] arr = new int[result.size()];
        for (int j = 0; j < result.size(); j++) {
            arr[j] = result.get(j);
        }
        return arr;
    }

    /**
     * 解析 Sponge 格式的调色板条目（blockstate 字符串格式）。
     */
    private static BlockState parseSpongePaletteEntry(String stateString, int index) {
        // 格式: "minecraft:block_name[prop1=val1,prop2=val2]"
        String blockName;
        String propsStr = null;

        int bracketIdx = stateString.indexOf('[');
        if (bracketIdx > 0) {
            blockName = stateString.substring(0, bracketIdx);
            propsStr = stateString.substring(bracketIdx + 1, stateString.length() - 1);
        } else {
            blockName = stateString;
        }

        Identifier blockId = Identifier.tryParse(blockName);
        if (blockId == null) {
            LitematListMod.LOGGER.warn("Sponge 调色板条目 #{} 无法解析 ID: {}", index, blockName);
            return Blocks.AIR.defaultBlockState();
        }

        Block block = BuiltInRegistries.BLOCK.get(blockId).get().value();
        BlockState state = block.defaultBlockState();

        if (propsStr != null && !propsStr.isEmpty()) {
            String[] props = propsStr.split(",");
            for (String prop : props) {
                String[] kv = prop.split("=", 2);
                if (kv.length == 2) {
                    for (net.minecraft.world.level.block.state.properties.Property<?> property : state.getProperties()) {
                        if (property.getName().equals(kv[0].trim())) {
                            state = applyProperty(state, property, kv[1].trim());
                            break;
                        }
                    }
                }
            }
        }

        return state;
    }

    /**
     * 解析单个 Region（Litematica 原生格式）。
     */
    private static void parseRegion(CompoundTag region, Map<Item, Integer> itemCounts,
                                     Map<Item, String> itemNames, String regionName, int version) {
        // 1. 读取 Size
        Optional<CompoundTag> sizeOpt = region.getCompound("Size");
        if (sizeOpt.isEmpty()) {
            LitematListMod.LOGGER.warn("Region '{}' 缺少 Size 字段", regionName);
            return;
        }
        CompoundTag sizeTag = sizeOpt.get();
        // 使用绝对值 —— 某些投影文件的 Size 值为负数（表示包围盒偏移），
        // 实际方块数 = |x| * |y| * |z|
        int sx = Math.abs(sizeTag.getInt("x").orElse(0));
        int sy = Math.abs(sizeTag.getInt("y").orElse(0));
        int sz = Math.abs(sizeTag.getInt("z").orElse(0));
        int totalBlocks = sx * sy * sz;
        LitematListMod.LOGGER.info("Region '{}' 尺寸: {}x{}x{} ({} 方块)", regionName, sx, sy, sz, totalBlocks);

        // 2. 读取 BlockStatePalette
        Optional<ListTag> paletteOpt = region.getList("BlockStatePalette");
        if (paletteOpt.isEmpty()) {
            LitematListMod.LOGGER.warn("Region '{}' 缺少 BlockStatePalette", regionName);
            return;
        }
        ListTag palette = paletteOpt.get();
        LitematListMod.LOGGER.info("Region '{}' 调色板大小: {}", regionName, palette.size());

        // 解析调色板条目
        List<BlockState> paletteStates = new ArrayList<>(palette.size());
        int failedEntries = 0;
        for (int i = 0; i < palette.size(); i++) {
            Tag element = palette.get(i);
            if (element instanceof CompoundTag stateTag) {
                try {
                    paletteStates.add(parsePaletteEntry(stateTag, i));
                } catch (Exception e) {
                    failedEntries++;
                    LitematListMod.LOGGER.warn("调色板条目 #{} 解析失败，使用空气方块替代: {}", i, e.getMessage());
                    paletteStates.add(Blocks.AIR.defaultBlockState());
                }
            } else {
                failedEntries++;
                LitematListMod.LOGGER.warn("调色板条目 #{} 不是 CompoundTag，类型: {}", i,
                        element != null ? element.getClass().getSimpleName() : "null");
                paletteStates.add(Blocks.AIR.defaultBlockState());
            }
        }
        if (failedEntries > 0) {
            LitematListMod.LOGGER.warn("Region '{}' 有 {} 个调色板条目解析失败", regionName, failedEntries);
        }
        if (paletteStates.isEmpty()) {
            LitematListMod.LOGGER.warn("Region '{}' 调色板为空", regionName);
            return;
        }

        // 3. 读取 BlockStates
        Tag blockStatesElement = region.get("BlockStates");
        if (blockStatesElement == null) {
            LitematListMod.LOGGER.warn("Region '{}' 缺少 BlockStates", regionName);
            return;
        }

        long[] blockStates = null;
        int blockStatesType = blockStatesElement.getId();

        if (blockStatesType == Tag.TAG_LONG_ARRAY) {
            blockStates = ((LongArrayTag) blockStatesElement).getAsLongArray();
            LitematListMod.LOGGER.info("Region '{}' BlockStates 类型: LongArrayTag ({} 个 long)", regionName, blockStates.length);
        } else if (blockStatesType == Tag.TAG_INT_ARRAY) {
            // 兼容：某些工具可能使用 int[] 存储
            int[] intArray = ((IntArrayTag) blockStatesElement).getAsIntArray();
            blockStates = new long[intArray.length];
            for (int i = 0; i < intArray.length; i++) {
                blockStates[i] = intArray[i] & 0xFFFFFFFFL;
            }
            LitematListMod.LOGGER.info("Region '{}' BlockStates 类型: IntArrayTag ({} 个 int)", regionName, blockStates.length);
        } else if (blockStatesType == Tag.TAG_BYTE_ARRAY) {
            // 兼容：Sponge 格式内嵌
            byte[] byteArray = ((ByteArrayTag) blockStatesElement).getAsByteArray();
            int[] decoded = decodeVarIntArray(byteArray);
            int bitsPerBlock = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteStates.size() - 1));
            long mask = (1L << bitsPerBlock) - 1;
            int blocksPerLong = 64 / bitsPerBlock;
            int longCount = (decoded.length + blocksPerLong - 1) / blocksPerLong;
            blockStates = new long[longCount];
            for (int i = 0; i < decoded.length; i++) {
                int longIdx = i / blocksPerLong;
                int bitOffset = (i % blocksPerLong) * bitsPerBlock;
                blockStates[longIdx] |= ((long) decoded[i] & mask) << bitOffset;
            }
            LitematListMod.LOGGER.info("Region '{}' BlockStates 类型: ByteArrayTag ({} 字节，解码后 {} 个 long)",
                    regionName, byteArray.length, blockStates.length);
        } else if (blockStatesType == Tag.TAG_LIST) {
            ListTag list = (ListTag) blockStatesElement;
            blockStates = new long[list.size()];
            int validCount = 0;
            for (int i = 0; i < list.size(); i++) {
                Tag item = list.get(i);
                if (item instanceof LongTag nbtLong) {
                    blockStates[i] = nbtLong.longValue();
                    validCount++;
                } else if (item instanceof IntTag nbtInt) {
                    blockStates[i] = nbtInt.intValue() & 0xFFFFFFFFL;
                    validCount++;
                }
            }
            LitematListMod.LOGGER.info("Region '{}' BlockStates 类型: ListTag ({} 个 long，{} 有效)",
                    regionName, blockStates.length, validCount);
        } else {
            LitematListMod.LOGGER.warn("Region '{}' BlockStates 类型不支持: type={}",
                    regionName, blockStatesType);
            return;
        }

        if (blockStates == null || blockStates.length == 0) {
            LitematListMod.LOGGER.warn("Region '{}' BlockStates 为空", regionName);
            return;
        }

        // 4. 解码方块状态
        int paletteSize = paletteStates.size();
        int bitsPerBlock = Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
        long mask = (1L << bitsPerBlock) - 1;
        int blocksPerLong = 64 / bitsPerBlock;

        int decodedBlocks = 0;
        int airCount = 0;

        for (long value : blockStates) {
            for (int j = 0; j < blocksPerLong && decodedBlocks < totalBlocks; j++) {
                int paletteIndex = (int) ((value >>> (j * bitsPerBlock)) & mask);
                if (paletteIndex >= 0 && paletteIndex < paletteStates.size()) {
                    BlockState state = paletteStates.get(paletteIndex);
                    if (!state.isAir()) {
                        Item item = state.getBlock().asItem();
                        if (item != Items.AIR) {
                            itemCounts.merge(item, 1, Integer::sum);
                            itemNames.putIfAbsent(item, state.getBlock().getName().getString());
                        }
                    } else {
                        airCount++;
                    }
                }
                decodedBlocks++;
            }
        }
        LitematListMod.LOGGER.info("Region '{}' 解码了 {} 个方块，其中空气 {} 个，非空气 {} 个",
                regionName, decodedBlocks, airCount, decodedBlocks - airCount);
    }

    /**
     * 解析调色板条目（Litematica 原生格式）。
     * 返回 BlockState，如果解析失败则返回 AIR。
     */
    private static BlockState parsePaletteEntry(CompoundTag stateTag, int index) {
        Optional<String> nameOpt = stateTag.getString("Name");
        if (nameOpt.isEmpty()) {
            LitematListMod.LOGGER.warn("调色板条目 #{} 缺少 Name 字段", index);
            return Blocks.AIR.defaultBlockState();
        }

        String blockName = nameOpt.get();
        Identifier blockId = Identifier.tryParse(blockName);
        if (blockId == null) {
            LitematListMod.LOGGER.warn("调色板条目 #{} 无法解析 Block ID: {}", index, blockName);
            return Blocks.AIR.defaultBlockState();
        }

        // 从方块注册表获取方块
        Block block = BuiltInRegistries.BLOCK.get(blockId).get().value();

        // 如果注册表返回 AIR 但方块名不是 air，尝试从物品注册表查找
        if (block == Blocks.AIR && !"minecraft:air".equals(blockName)) {
            // 尝试从 ITEM 注册表查找对应物品，再反查方块
            Item item = BuiltInRegistries.ITEM.get(blockId).get().value();
            if (item != null && item != Items.AIR) {
                Block itemBlock = Block.byItem(item);
                if (itemBlock != Blocks.AIR) {
                    LitematListMod.LOGGER.info("调色板条目 #{} 通过物品注册表找到方块: {} -> {}", index, blockName, itemBlock);
                    block = itemBlock;
                }
            }
            if (block == Blocks.AIR) {
                LitematListMod.LOGGER.warn("调色板条目 #{} 方块未在注册表中找到: {} (可能是新版本方块或模组方块)", index, blockName);
            }
        }

        BlockState state = block.defaultBlockState();

        // 解析 Properties
        Optional<CompoundTag> propsOpt = stateTag.getCompound("Properties");
        if (propsOpt.isPresent()) {
            CompoundTag props = propsOpt.get();
            for (String key : props.keySet()) {
                Optional<String> valOpt = props.getString(key);
                if (valOpt.isEmpty()) continue;
                String value = valOpt.get();
                boolean propertyFound = false;
                for (net.minecraft.world.level.block.state.properties.Property<?> property : state.getProperties()) {
                    if (property.getName().equals(key)) {
                        state = applyProperty(state, property, value);
                        propertyFound = true;
                        break;
                    }
                }
                if (!propertyFound) {
                    LitematListMod.LOGGER.debug("调色板条目 #{} 属性 '{}' 未在当前方块状态中找到，可能已变更", index, key);
                }
            }
        }

        return state;
    }

    @SuppressWarnings("unchecked")
    private static <T extends Comparable<T>> BlockState applyProperty(
            BlockState state, net.minecraft.world.level.block.state.properties.Property<T> property, String value) {
        try {
            Optional<T> parsed = property.getValue(value);
            if (parsed.isPresent()) {
                return state.setValue(property, parsed.get());
            }
            LitematListMod.LOGGER.debug("属性值解析失败: {}={} (无效值)", property.getName(), value);
            return state;
        } catch (Exception e) {
            LitematListMod.LOGGER.warn("应用方块属性失败: {}={}, 使用默认值", property.getName(), value);
            return state;
        }
    }
}