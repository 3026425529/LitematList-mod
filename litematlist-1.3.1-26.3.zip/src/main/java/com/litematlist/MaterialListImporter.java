package com.litematlist;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;

/**
 * 解析 Litematica 导出的 ASCII 表格 txt 文件，提取材料列表。
 * 支持三种格式：
 * 1. 放置原理图'...'的材料列表
 * 2. 原理图'...'材料列表（1/1区域）
 * 3. 选区'...'区域分析
 * 格式示例：
 * +---------+-------+---------+-----------+
 * | 放置原理图'Unnamed'的材料列表                   |
 * +---------+-------+---------+-----------+
 * | Item    | Total | Missing | Available |
 * +---------+-------+---------+-----------+
 * | 铁块      |   142 |      98 |         1 |
 * ...
 */
public class MaterialListImporter {

    private static final Logger LOGGER = LoggerFactory.getLogger("litematlist.MaterialListImporter");
    private static final Gson GSON = new Gson();

    /**
     * 解析结果
     */
    public record ImportResult(String schematicName, List<LitematicReader.MaterialEntry> materials,
                                int totalItems, int totalMissing) {}

    /**
     * 预览信息（不完整解析，仅获取名称和统计）
     */
    public record PreviewInfo(String schematicName, int totalItems, int totalMissing) {}

    /**
     * 从 txt 文件导入材料列表（完整解析，含物品验证）。
     *
     * @return 解析结果，失败返回 null
     */
    public static ImportResult importFromFile(Path filePath) {
        String fileName = filePath.getFileName().toString().toLowerCase();
        if (fileName.endsWith(".json")) {
            return importFromJson(filePath);
        }
        return importFromTxt(filePath);
    }

    private static ImportResult importFromTxt(Path filePath) {
        PreviewInfo preview = parsePreview(filePath);
        if (preview == null) return null;

        File file = filePath.toFile();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            Map<Item, Integer> itemCounts = new LinkedHashMap<>();
            Map<Item, Integer> itemMissing = new LinkedHashMap<>();
            Map<Item, String> itemNames = new LinkedHashMap<>();
            boolean inDataSection = false;
            int totalItems = 0;
            int totalMissing = 0;
            int skippedCount = 0;

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("+") || line.isEmpty()) continue;
                if (line.contains("Item") && line.contains("Total")) {
                    inDataSection = true;
                    continue;
                }
                if (line.contains("原理图") && line.contains("材料列表")) continue;
                if (line.contains("选区") && line.contains("区域分析")) continue;

                if (inDataSection && line.startsWith("|")) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 4) {
                        String itemName = parts[1].trim();
                        String totalStr = parts[2].trim();
                        String missingStr = parts[3].trim();
                        if (itemName.isEmpty() || itemName.equals("Item")) continue;

                        try {
                            int total = Integer.parseInt(totalStr);
                            int missing = Integer.parseInt(missingStr);
                            if (total > 0) {
                                Item item = findItem(itemName);
                                if (item == Items.AIR) {
                                    LOGGER.warn("跳过未匹配物品: '{}'", itemName);
                                    skippedCount++;
                                    continue; // 宽松模式：跳过不匹配的物品，不中断整个导入
                                }
                                itemCounts.merge(item, total, Integer::sum);
                                itemMissing.merge(item, missing, Integer::sum);
                                itemNames.putIfAbsent(item, itemName);
                                totalItems += total;
                                totalMissing += missing;
                            }
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }

            if (itemCounts.isEmpty()) {
                LOGGER.warn("未从文件中解析到有效材料: {}", filePath);
                return null;
            }

            List<LitematicReader.MaterialEntry> materials = new ArrayList<>();
            for (Map.Entry<Item, Integer> entry : itemCounts.entrySet()) {
                Item item = entry.getKey();
                materials.add(new LitematicReader.MaterialEntry(
                        item, itemNames.getOrDefault(item, item.getName(new ItemStack(item)).getString()), entry.getValue()));
            }
            materials.sort((a, b) -> Integer.compare(b.totalCount(), a.totalCount()));

            // 存储缺失数量到缓存（MaterialEntry 没有 missingCount 字段）
            cacheMissingCounts.put(filePath, itemMissing);

            LOGGER.info("从 {} 导入成功: 原理图='{}', {} 种物品, 总计{}, 缺失{}, 跳过{}个",
                    filePath, preview.schematicName(), materials.size(), totalItems, totalMissing, skippedCount);
            return new ImportResult(preview.schematicName(), materials, totalItems, totalMissing);

        } catch (Exception e) {
            LOGGER.error("导入材料列表失败: {}", filePath, e);
            return null;
        }
    }

    // ---- 缺失数量缓存（因为 MaterialEntry 只有 3 个字段） ----
    private static final Map<Path, Map<Item, Integer>> cacheMissingCounts = new HashMap<>();

    /** 获取指定路径的缺失数量映射 */
    public static Map<Item, Integer> getMissingCounts(Path filePath) {
        return cacheMissingCounts.getOrDefault(filePath, Collections.emptyMap());
    }

    /**
     * 快速预览 txt 文件（只解析名称和统计，不验证物品）。
     */
    public static PreviewInfo parsePreview(Path filePath) {
        String fileName = filePath.getFileName().toString().toLowerCase();
        if (fileName.endsWith(".json")) {
            return parseJsonPreview(filePath);
        }
        return parseTxtPreview(filePath);
    }

    private static PreviewInfo parseTxtPreview(Path filePath) {
        File file = filePath.toFile();
        if (!file.exists()) return null;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String schematicName = null;
            boolean inDataSection = false;
            int totalItems = 0;
            int totalMissing = 0;
            boolean hasValidFormat = false;

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("+") || line.isEmpty()) continue;

                if (line.contains("原理图") && line.contains("材料列表")) {
                    int start = line.indexOf("'");
                    int end = line.lastIndexOf("'");
                    if (start >= 0 && end > start) {
                        schematicName = line.substring(start + 1, end);
                    }
                    hasValidFormat = true;
                    continue;
                }
                if (line.contains("选区") && line.contains("区域分析")) {
                    int start = line.indexOf("'");
                    int end = line.lastIndexOf("'");
                    if (start >= 0 && end > start) {
                        schematicName = line.substring(start + 1, end);
                    }
                    hasValidFormat = true;
                    continue;
                }

                if (line.contains("Item") && line.contains("Total")) {
                    inDataSection = true;
                    continue;
                }

                if (inDataSection && line.startsWith("|")) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 4) {
                        String itemName = parts[1].trim();
                        if (itemName.isEmpty() || itemName.equals("Item")) continue;
                        try {
                            totalItems += Integer.parseInt(parts[2].trim());
                            totalMissing += Integer.parseInt(parts[3].trim());
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }

            if (!hasValidFormat || totalItems == 0) return null;

            if (schematicName == null || schematicName.isEmpty()) {
                String fileName = file.getName();
                int dot = fileName.lastIndexOf('.');
                schematicName = dot > 0 ? fileName.substring(0, dot) : fileName;
            }

            return new PreviewInfo(schematicName, totalItems, totalMissing);

        } catch (Exception e) {
            return null;
        }
    }

    // ---- JSON 导入 ----

    public static ImportResult importFromJson(Path filePath) {
        PreviewInfo preview = parseJsonPreview(filePath);
        if (preview == null) return null;

        File file = filePath.toFile();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            JsonArray array;
            JsonElement root = GSON.fromJson(reader, JsonElement.class);
            if (root == null) {
                LOGGER.warn("JSON 文件为空: {}", filePath);
                return null;
            }
            // 支持两种 JSON 结构：顶层数组 或 对象内嵌 Materials 数组
            if (root.isJsonArray()) {
                array = root.getAsJsonArray();
            } else if (root.isJsonObject() && root.getAsJsonObject().has("Materials")) {
                array = root.getAsJsonObject().getAsJsonArray("Materials");
            } else {
                LOGGER.warn("JSON 文件格式不正确: {}", filePath);
                return null;
            }
            if (array == null || array.isEmpty()) {
                LOGGER.warn("JSON 文件为空或格式不正确: {}", filePath);
                return null;
            }

            Map<Item, Integer> itemCounts = new LinkedHashMap<>();
            int totalItems = 0;
            int skippedCount = 0;

            for (JsonElement elem : array) {
                JsonObject obj = elem.getAsJsonObject();

                String rawItem;
                int totalEstimate;
                // 支持两种 JSON 格式：RawItem/TotalEstimate 和 Item/Count
                if (obj.has("RawItem")) {
                    rawItem = obj.get("RawItem").getAsString();
                    totalEstimate = obj.get("TotalEstimate").getAsInt();
                } else if (obj.has("Item")) {
                    rawItem = obj.get("Item").getAsString();
                    totalEstimate = obj.has("Total") ? obj.get("Total").getAsInt() : obj.get("Count").getAsInt();
                } else {
                    LOGGER.warn("跳过无效 JSON 条目，缺少 Item 或 RawItem 字段");
                    skippedCount++;
                    continue;
                }

                if (totalEstimate <= 0) continue;

                Identifier id = Identifier.tryParse(rawItem);
                if (id == null) {
                    LOGGER.warn("跳过无效物品ID: '{}'", rawItem);
                    skippedCount++;
                    continue;
                }
                var holder = BuiltInRegistries.ITEM.get(id);
                if (holder.isEmpty()) {
                    LOGGER.warn("跳过未匹配物品: '{}'", rawItem);
                    skippedCount++;
                    continue;
                }
                Item item = holder.get().value();
                if (item == Items.AIR) {
                    LOGGER.warn("跳过未匹配物品: '{}'", rawItem);
                    skippedCount++;
                    continue;
                }
                itemCounts.merge(item, totalEstimate, Integer::sum);
                totalItems += totalEstimate;
            }

            if (itemCounts.isEmpty()) {
                LOGGER.warn("未从 JSON 文件中解析到有效材料: {}", filePath);
                return null;
            }

            List<LitematicReader.MaterialEntry> materials = new ArrayList<>();
            for (Map.Entry<Item, Integer> entry : itemCounts.entrySet()) {
                Item item = entry.getKey();
                materials.add(new LitematicReader.MaterialEntry(
                        item, item.getName(new ItemStack(item)).getString(), entry.getValue()));
            }
            materials.sort((a, b) -> Integer.compare(b.totalCount(), a.totalCount()));

            LOGGER.info("从 {} 导入成功: 原理图='{}', {} 种物品, 总计{}, 跳过{}个",
                    filePath, preview.schematicName(), materials.size(), totalItems, skippedCount);
            return new ImportResult(preview.schematicName(), materials, totalItems, 0);

        } catch (Exception e) {
            LOGGER.error("导入 JSON 材料列表失败: {}", filePath, e);
            return null;
        }
    }

    public static PreviewInfo parseJsonPreview(Path filePath) {
        File file = filePath.toFile();
        if (!file.exists()) return null;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            JsonArray array;
            JsonElement root = GSON.fromJson(reader, JsonElement.class);
            if (root == null) return null;
            // 支持两种 JSON 结构：顶层数组 或 对象内嵌 Materials 数组
            if (root.isJsonArray()) {
                array = root.getAsJsonArray();
            } else if (root.isJsonObject() && root.getAsJsonObject().has("Materials")) {
                array = root.getAsJsonObject().getAsJsonArray("Materials");
            } else {
                return null;
            }
            if (array == null || array.isEmpty()) return null;

            int totalItems = 0;
            int entryCount = 0;

            for (JsonElement elem : array) {
                JsonObject obj = elem.getAsJsonObject();
                int totalEstimate;
                // 支持 TotalEstimate / Total / Count 三种字段名
                if (obj.has("TotalEstimate")) {
                    totalEstimate = obj.get("TotalEstimate").getAsInt();
                } else if (obj.has("Total")) {
                    totalEstimate = obj.get("Total").getAsInt();
                } else if (obj.has("Count")) {
                    totalEstimate = obj.get("Count").getAsInt();
                } else {
                    continue;
                }
                if (totalEstimate > 0) {
                    totalItems += totalEstimate;
                    entryCount++;
                }
            }

            if (entryCount == 0) return null;

            String fileName = file.getName();
            int dot = fileName.lastIndexOf('.');
            String schematicName = dot > 0 ? fileName.substring(0, dot) : fileName;

            return new PreviewInfo(schematicName, totalItems, 0);

        } catch (Exception e) {
            return null;
        }
    }

    // ---- 物品名称缓存 ----
    private static Map<String, Item> itemByNameCache = null;

    private static void ensureItemCache() {
        if (itemByNameCache != null) return;
        itemByNameCache = new HashMap<>();
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == Items.AIR) continue;
            // 使用 getName().getString() 获取翻译后的显示名称（最可靠的方式）
            String name = item.getName(new ItemStack(item)).getString();
            if (name != null && !name.isEmpty()) {
                itemByNameCache.putIfAbsent(name, item);
            }
            // 同时用 registry path 作为英文名/ID 匹配的 fallback
            Identifier id = BuiltInRegistries.ITEM.getKey(item);
            if (id != null) {
                String path = id.getPath().replace('_', ' ');
                itemByNameCache.putIfAbsent(path, item);
            }
        }
        LOGGER.info("物品名称缓存已构建: {} 个条目", itemByNameCache.size());
        // 输出前 10 条缓存条目用于调试
        int count = 0;
        for (Map.Entry<String, Item> entry : itemByNameCache.entrySet()) {
            if (count++ >= 10) break;
            LOGGER.info("  缓存: '{}' -> {}", entry.getKey(), BuiltInRegistries.ITEM.getKey(entry.getValue()));
        }
    }

    /**
     * 根据物品名（中文或英文）查找 Item。
     */
    private static Item findItem(String name) {
        ensureItemCache();
        // 直接匹配
        Item item = itemByNameCache.get(name);
        if (item != null) {
            LOGGER.debug("物品匹配成功: '{}' -> {}", name, BuiltInRegistries.ITEM.getKey(item));
            return item;
        }
        LOGGER.debug("物品未在缓存中找到: '{}'，尝试 Identifier 匹配", name);
        // 尝试通过 Identifier 查找
        Identifier id = Identifier.tryParse(name);
        if (id != null) {
            var holder = BuiltInRegistries.ITEM.get(id);
            if (holder.isPresent()) {
                item = holder.get().value();
                if (item != Items.AIR) return item;
            }
        }
        id = Identifier.tryParse("minecraft:" + name.toLowerCase().replace(' ', '_'));
        if (id != null) {
            var holder = BuiltInRegistries.ITEM.get(id);
            if (holder.isPresent()) {
                item = holder.get().value();
                if (item != Items.AIR) return item;
            }
        }
        return Items.AIR;
    }
}