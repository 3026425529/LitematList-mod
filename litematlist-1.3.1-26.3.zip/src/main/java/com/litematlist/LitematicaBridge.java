package com.litematlist;

import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacementManager;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 与 Litematica 模组的桥接层。
 * 使用 Litematica 的公开 API 获取当前已加载的原理图列表。
 */
public class LitematicaBridge {

    public static boolean isAvailable() {
        try {
            // 检查 Litematica 是否已加载
            DataManager.getInstance();
            return true;
        } catch (NoClassDefFoundError | Exception e) {
            return false;
        }
    }

    /**
     * 获取 Litematica 中当前已加载的所有原理图。
     */
    public static List<SchematicInfo> getLoadedSchematics() {
        List<SchematicInfo> result = new ArrayList<>();
        try {
            SchematicPlacementManager manager = DataManager.getSchematicPlacementManager();
            List<SchematicPlacement> placements = manager.getAllSchematicsPlacements();

            LitematListMod.LOGGER.info("从 Litematica 获取到 {} 个已加载的原理图", placements.size());

            for (SchematicPlacement placement : placements) {
                String name = placement.getName();
                Path filePath = placement.getSchematicFile();
                if (filePath != null) {
                    result.add(new SchematicInfo(name, filePath));
                    LitematListMod.LOGGER.info("  原理图: {} -> {}", name, filePath);
                } else {
                    LitematListMod.LOGGER.warn("  原理图 {} 没有关联的文件路径", name);
                }
            }
        } catch (Exception e) {
            LitematListMod.LOGGER.error("从 Litematica 获取原理图列表失败", e);
        }
        return result;
    }

    /**
     * 从 schematics 文件夹递归扫描 .litematic 文件。
     */
    public static List<SchematicInfo> scanSchematicsFolder() {
        List<SchematicInfo> result = new ArrayList<>();
        Path schematicsDir = Minecraft.getInstance().gameDirectory.toPath().resolve("schematics");
        File dir = schematicsDir.toFile();

        if (!dir.exists() || !dir.isDirectory()) {
            return result;
        }

        scanDirectory(dir, schematicsDir, result);
        return result;
    }

    private static void scanDirectory(File currentDir, Path basePath, List<SchematicInfo> result) {
        File[] files = currentDir.listFiles();
        if (files == null) return;

        for (File file : files) {
            if (file.isDirectory()) {
                scanDirectory(file, basePath, result);
            } else if (file.getName().endsWith(".litematic")) {
                String name = file.getName();
                int dotIndex = name.lastIndexOf('.');
                String displayName = dotIndex > 0 ? name.substring(0, dotIndex) : name;
                // 显示相对路径
                Path relativePath = basePath.relativize(file.toPath());
                if (relativePath.getParent() != null) {
                    displayName = relativePath.getParent().toString()
                            .replace(File.separatorChar, '/') + "/" + displayName;
                }
                result.add(new SchematicInfo(displayName, file.toPath()));
            }
        }
    }

    public record SchematicInfo(String name, Path filePath) {}
}