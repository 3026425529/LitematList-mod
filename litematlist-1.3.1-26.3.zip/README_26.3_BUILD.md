LitematList 1.3.1 ported from Minecraft 26.1.2 to 26.3. Build: Gradle 9.6.0 + Java 25.
